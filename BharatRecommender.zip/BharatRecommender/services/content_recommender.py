import logging
from typing import Dict, List, Optional
from models import User, Content, Recommendation
from services.api_integrations import APIIntegrations
from services.cultural_context import CulturalContext
from utils.cache import get_cached_recommendations, cache_recommendations
import random
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class ContentRecommender:
    def __init__(self):
        """Initialize content recommendation engine"""
        self.api_integrations = APIIntegrations()
        self.cultural_context = CulturalContext()
        
        # Mood to content type mapping
        self.mood_content_mapping = {
            'happy': {
                'video': ['comedy', 'romance', 'musical', 'celebration'],
                'music': ['upbeat', 'bollywood', 'pop', 'dance'],
                'podcast': ['comedy', 'success_stories', 'motivational'],
                'book': ['romance', 'adventure', 'success_stories']
            },
            'excited': {
                'video': ['action', 'adventure', 'sports', 'thriller'],
                'music': ['energetic', 'rock', 'electronic', 'workout'],
                'podcast': ['sports', 'adventure', 'technology'],
                'book': ['thriller', 'adventure', 'mystery']
            },
            'calm': {
                'video': ['nature', 'documentary', 'meditation', 'slow_cinema'],
                'music': ['classical', 'ambient', 'instrumental', 'devotional'],
                'podcast': ['meditation', 'philosophy', 'nature'],
                'book': ['philosophy', 'spirituality', 'poetry']
            },
            'stressed': {
                'video': ['meditation', 'yoga', 'comedy', 'nature'],
                'music': ['relaxing', 'classical', 'ambient', 'devotional'],
                'podcast': ['meditation', 'self_help', 'calming'],
                'book': ['self_help', 'meditation', 'motivational']
            },
            'sad': {
                'video': ['uplifting', 'comedy', 'inspirational', 'family'],
                'music': ['soothing', 'devotional', 'healing', 'soft'],
                'podcast': ['inspirational', 'motivational', 'healing'],
                'book': ['inspirational', 'self_help', 'spiritual']
            }
        }
        
        # Platform priorities based on content type and mood
        self.platform_priorities = {
            'video': {
                'stressed': ['youtube', 'jiohotstar', 'zee5'],
                'happy': ['jiohotstar', 'youtube', 'zee5'],
                'excited': ['youtube', 'jiohotstar', 'zee5'],
                'calm': ['youtube', 'zee5', 'jiohotstar'],
                'sad': ['youtube', 'jiohotstar', 'zee5']
            },
            'music': {
                'all': ['spotify', 'jiosaavn', 'gaana', 'youtube']
            },
            'podcast': {
                'all': ['spotify', 'jiosaavn', 'youtube']
            }
        }

    def get_recommendations(self, mood: str, language: str, platforms: List[str], 
                          user: Optional[User] = None, mood_analysis: Dict = None) -> Dict:
        """Generate comprehensive content recommendations based on mood and preferences"""
        try:
            # Check cache first
            cache_key = f"{mood}_{language}_{'_'.join(sorted(platforms))}"
            cached_result = get_cached_recommendations(cache_key)
            if cached_result is not None:
                logger.info(f"Returning cached recommendations for {cache_key}")
                return cached_result
            
            recommendations = {
                'mood': mood,
                'language': language,
                'platforms': platforms,
                'content': {
                    'video': [],
                    'music': [],
                    'podcast': [],
                    'book': []
                },
                'cultural_suggestions': [],
                'explanation': self.get_mood_explanation(mood, language),
                'generated_at': datetime.utcnow().isoformat()
            }
            
            # Get cultural context and boosts
            cultural_boosts = self.cultural_context.get_cultural_boosts(language)
            current_events = self.cultural_context.get_current_events()
            
            # Generate recommendations for each content type
            for content_type in ['video', 'music', 'podcast']:
                if self.should_include_content_type(content_type, platforms):
                    content_recs = self.get_content_by_type(
                        content_type, mood, language, platforms, cultural_boosts
                    )
                    recommendations['content'][content_type] = content_recs
            
            # Add cultural suggestions
            recommendations['cultural_suggestions'] = self.get_cultural_suggestions(
                mood, language, current_events
            )
            
            # Cache the results
            cache_recommendations(cache_key, recommendations)
            
            logger.info(f"Generated {sum(len(v) for v in recommendations['content'].values())} recommendations")
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating recommendations: {e}")
            return self.get_fallback_recommendations(mood, language)

    def should_include_content_type(self, content_type: str, platforms: List[str]) -> bool:
        """Check if content type should be included based on platform selection"""
        if content_type == 'video':
            return any(p in platforms for p in ['youtube', 'jiohotstar', 'zee5', 'sonyliv'])
        elif content_type == 'music':
            return any(p in platforms for p in ['spotify', 'jiosaavn', 'gaana', 'youtube'])
        elif content_type == 'podcast':
            return any(p in platforms for p in ['spotify', 'jiosaavn', 'youtube'])
        return False

    def get_content_by_type(self, content_type: str, mood: str, language: str, 
                           platforms: List[str], cultural_boosts: Dict) -> List[Dict]:
        """Get content recommendations for a specific type"""
        try:
            content_list = []
            mood_genres = self.mood_content_mapping.get(mood, {}).get(content_type, [])
            
            # Determine platform priority
            platform_order = self.get_platform_priority(content_type, mood, platforms)
            
            for platform in platform_order:
                try:
                    if content_type == 'video':
                        platform_content = self.get_video_content(platform, mood, language, mood_genres)
                    elif content_type == 'music':
                        platform_content = self.get_music_content(platform, mood, language, mood_genres)
                    elif content_type == 'podcast':
                        platform_content = self.get_podcast_content(platform, mood, language, mood_genres)
                    else:
                        continue
                    
                    # Apply cultural boosts
                    platform_content = self.apply_cultural_boosts(platform_content, cultural_boosts)
                    content_list.extend(platform_content[:3])  # Limit per platform
                    
                except Exception as e:
                    logger.warning(f"Error getting {content_type} from {platform}: {e}")
                    continue
            
            return content_list[:10]  # Limit total recommendations
            
        except Exception as e:
            logger.error(f"Error getting {content_type} content: {e}")
            return []

    def get_platform_priority(self, content_type: str, mood: str, platforms: List[str]) -> List[str]:
        """Get platform priority order based on content type and mood"""
        if content_type in self.platform_priorities:
            if mood in self.platform_priorities[content_type]:
                priority = self.platform_priorities[content_type][mood]
            else:
                priority = self.platform_priorities[content_type].get('all', platforms)
            
            # Filter by available platforms
            return [p for p in priority if p in platforms]
        
        return platforms

    def get_video_content(self, platform: str, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get video content recommendations from specific platform"""
        try:
            if platform == 'youtube':
                return self.api_integrations.get_youtube_videos(mood, language, genres)
            elif platform in ['jiohotstar', 'zee5', 'sonyliv']:
                return self.api_integrations.get_ott_content(platform, mood, language, genres)
            else:
                return []
        except Exception as e:
            logger.error(f"Error getting video content from {platform}: {e}")
            return []

    def get_music_content(self, platform: str, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get music content recommendations from specific platform"""
        try:
            if platform == 'spotify':
                return self.api_integrations.get_spotify_music(mood, language, genres)
            elif platform in ['jiosaavn', 'gaana']:
                return self.api_integrations.get_indian_music(platform, mood, language, genres)
            elif platform == 'youtube':
                return self.api_integrations.get_youtube_music(mood, language, genres)
            else:
                return []
        except Exception as e:
            logger.error(f"Error getting music content from {platform}: {e}")
            return []

    def get_podcast_content(self, platform: str, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get podcast content recommendations from specific platform"""
        try:
            if platform == 'spotify':
                return self.api_integrations.get_spotify_podcasts(mood, language, genres)
            elif platform in ['jiosaavn']:
                return self.api_integrations.get_indian_podcasts(platform, mood, language, genres)
            elif platform == 'youtube':
                return self.api_integrations.get_youtube_podcasts(mood, language, genres)
            else:
                return []
        except Exception as e:
            logger.error(f"Error getting podcast content from {platform}: {e}")
            return []

    def apply_cultural_boosts(self, content_list: List[Dict], cultural_boosts: Dict) -> List[Dict]:
        """Apply cultural context boosts to content recommendations"""
        try:
            for content in content_list:
                # Boost content based on cultural events
                if cultural_boosts.get('festival_boost'):
                    if any(tag in content.get('tags', []) for tag in cultural_boosts['festival_boost']):
                        content['cultural_boost'] = True
                        content['boost_reason'] = "Festival special content"
                
                # Regional preference boost
                if cultural_boosts.get('regional_preference'):
                    if content.get('language') in cultural_boosts['regional_preference']:
                        content['regional_boost'] = True
            
            return content_list
            
        except Exception as e:
            logger.error(f"Error applying cultural boosts: {e}")
            return content_list

    def get_cultural_suggestions(self, mood: str, language: str, current_events: List[Dict]) -> List[Dict]:
        """Get culturally relevant suggestions based on mood and current events"""
        try:
            suggestions = []
            
            # Festival-based suggestions
            for event in current_events:
                if mood in event.get('mood_influence', {}):
                    suggestions.append({
                        'type': 'festival',
                        'title': f"{event['name']} Special Content",
                        'description': f"Special {mood} content for {event['name']}",
                        'content_boost': event.get('content_boost', {}),
                        'language': language
                    })
            
            # Language-specific cultural suggestions
            cultural_suggestions = {
                'hindi': {
                    'stressed': "योग और ध्यान की वीडियो देखें (Watch yoga and meditation videos)",
                    'happy': "बॉलीवुड डांस वीडियो और गाने सुनें (Enjoy Bollywood dance videos and songs)",
                    'calm': "शास्त्रीय संगीत और भजन सुनें (Listen to classical music and bhajans)"
                },
                'tamil': {
                    'stressed': "தமிழ் பாரம்பரிய இசை கேளுங்கள் (Listen to Tamil traditional music)",
                    'happy': "தமிழ் திரை பாடல்கள் கேளுங்கள் (Enjoy Tamil film songs)",
                    'calm': "தியானம் மற்றும் ஆன்மீக இசை (Meditation and spiritual music)"
                },
                'telugu': {
                    'stressed': "తెలుగు భక్తి పాటలు వినండి (Listen to Telugu devotional songs)",
                    'happy': "తెలుగు సినిమా పాటలు వినండి (Enjoy Telugu movie songs)",
                    'calm': "క్లాసికల్ సంగీతం వినండి (Listen to classical music)"
                }
            }
            
            if language in cultural_suggestions and mood in cultural_suggestions[language]:
                suggestions.append({
                    'type': 'cultural_tip',
                    'title': 'Cultural Recommendation',
                    'description': cultural_suggestions[language][mood],
                    'language': language
                })
            
            return suggestions
            
        except Exception as e:
            logger.error(f"Error getting cultural suggestions: {e}")
            return []

    def get_mood_explanation(self, mood: str, language: str) -> Dict:
        """Get explanation for mood-based recommendations"""
        explanations = {
            'hindi': {
                'happy': "खुशी के मूड के लिए खुशमिजाज और उत्साहजनक कंटेंट चुना गया है",
                'excited': "उत्साह के लिए एडवेंचर और एक्शन से भरपूर कंटेंट",
                'calm': "शांति के लिए आरामदायक और ध्यान से भरे कंटेंट",
                'stressed': "तनाव कम करने के लिए शांत और प्रेरणादायक कंटेंट",
                'sad': "उदासी दूर करने के लिए प्रेरणादायक और खुशी देने वाले कंटेंट"
            },
            'english': {
                'happy': "Cheerful and uplifting content selected for your happy mood",
                'excited': "Adventure and action-packed content for your excitement",
                'calm': "Peaceful and meditative content for relaxation",
                'stressed': "Calming and inspirational content to reduce stress",
                'sad': "Uplifting and motivational content to brighten your mood"
            }
        }
        
        lang_explanations = explanations.get(language, explanations['english'])
        return {
            'text': lang_explanations.get(mood, f"Content curated for your {mood} mood"),
            'language': language
        }

    def get_fallback_recommendations(self, mood: str, language: str) -> Dict:
        """Provide fallback recommendations when main system fails"""
        return {
            'mood': mood,
            'language': language,
            'platforms': [],
            'content': {
                'video': [{
                    'title': 'Content temporarily unavailable',
                    'description': 'Please try again later',
                    'platform': 'system',
                    'type': 'error'
                }],
                'music': [],
                'podcast': [],
                'book': []
            },
            'cultural_suggestions': [],
            'explanation': {
                'text': 'Recommendations temporarily unavailable. Please try again.',
                'language': language
            },
            'error': True
        }
