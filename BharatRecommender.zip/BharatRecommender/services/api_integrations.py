import os
import logging
import requests
from typing import Dict, List
import random
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class APIIntegrations:
    def __init__(self):
        """Initialize API integrations with various platforms"""
        # API Keys from environment
        self.youtube_api_key = os.getenv("YOUTUBE_API_KEY", "")
        self.spotify_client_id = os.getenv("SPOTIFY_CLIENT_ID", "")
        self.spotify_client_secret = os.getenv("SPOTIFY_CLIENT_SECRET", "")
        
        # API endpoints
        self.youtube_base_url = "https://www.googleapis.com/youtube/v3"
        self.spotify_base_url = "https://api.spotify.com/v1"
        
        # Initialize Spotify token
        self.spotify_token = self.get_spotify_token()
        
        # Mock data for platforms without public APIs
        self.mock_ott_content = self.initialize_mock_ott_content()
        self.mock_music_content = self.initialize_mock_music_content()

    def get_spotify_token(self) -> str:
        """Get Spotify access token using client credentials flow"""
        try:
            if not self.spotify_client_id or not self.spotify_client_secret:
                logger.warning("Spotify credentials not found, using mock data")
                return ""
            
            auth_url = "https://accounts.spotify.com/api/token"
            auth_data = {
                'grant_type': 'client_credentials',
                'client_id': self.spotify_client_id,
                'client_secret': self.spotify_client_secret
            }
            
            response = requests.post(auth_url, data=auth_data)
            if response.status_code == 200:
                return response.json().get('access_token', '')
            else:
                logger.error(f"Failed to get Spotify token: {response.status_code}")
                return ""
                
        except Exception as e:
            logger.error(f"Error getting Spotify token: {e}")
            return ""

    def get_youtube_videos(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get YouTube video recommendations"""
        try:
            if not self.youtube_api_key:
                logger.warning("YouTube API key not found, using mock data")
                return self.get_mock_youtube_videos(mood, language, genres)
            
            # Construct search query based on mood and language
            search_terms = self.build_search_terms(mood, language, genres, 'video')
            
            videos = []
            for search_term in search_terms[:2]:  # Limit API calls
                try:
                    url = f"{self.youtube_base_url}/search"
                    params = {
                        'part': 'snippet',
                        'q': search_term,
                        'type': 'video',
                        'maxResults': 5,
                        'key': self.youtube_api_key,
                        'relevanceLanguage': self.map_language_code(language),
                        'safeSearch': 'moderate'
                    }
                    
                    response = requests.get(url, params=params)
                    if response.status_code == 200:
                        data = response.json()
                        for item in data.get('items', []):
                            video = self.format_youtube_video(item, mood)
                            videos.append(video)
                    else:
                        logger.error(f"YouTube API error: {response.status_code}")
                        
                except Exception as e:
                    logger.error(f"Error fetching YouTube videos for {search_term}: {e}")
                    continue
            
            return videos[:10]  # Return top 10
            
        except Exception as e:
            logger.error(f"Error in get_youtube_videos: {e}")
            return self.get_mock_youtube_videos(mood, language, genres)

    def get_spotify_music(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get Spotify music recommendations"""
        try:
            if not self.spotify_token:
                logger.warning("Spotify token not available, using mock data")
                return self.get_mock_spotify_music(mood, language, genres)
            
            headers = {'Authorization': f'Bearer {self.spotify_token}'}
            search_terms = self.build_search_terms(mood, language, genres, 'music')
            
            tracks = []
            for search_term in search_terms[:2]:
                try:
                    url = f"{self.spotify_base_url}/search"
                    params = {
                        'q': search_term,
                        'type': 'track',
                        'market': 'IN',  # India market
                        'limit': 5
                    }
                    
                    response = requests.get(url, headers=headers, params=params)
                    if response.status_code == 200:
                        data = response.json()
                        for item in data.get('tracks', {}).get('items', []):
                            track = self.format_spotify_track(item, mood)
                            tracks.append(track)
                    else:
                        logger.error(f"Spotify API error: {response.status_code}")
                        
                except Exception as e:
                    logger.error(f"Error fetching Spotify tracks for {search_term}: {e}")
                    continue
            
            return tracks[:10]
            
        except Exception as e:
            logger.error(f"Error in get_spotify_music: {e}")
            return self.get_mock_spotify_music(mood, language, genres)

    def get_spotify_podcasts(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get Spotify podcast recommendations"""
        try:
            if not self.spotify_token:
                return self.get_mock_podcasts(mood, language, genres)
            
            headers = {'Authorization': f'Bearer {self.spotify_token}'}
            search_terms = self.build_search_terms(mood, language, genres, 'podcast')
            
            podcasts = []
            for search_term in search_terms[:2]:
                try:
                    url = f"{self.spotify_base_url}/search"
                    params = {
                        'q': search_term,
                        'type': 'show',
                        'market': 'IN',
                        'limit': 3
                    }
                    
                    response = requests.get(url, headers=headers, params=params)
                    if response.status_code == 200:
                        data = response.json()
                        for item in data.get('shows', {}).get('items', []):
                            podcast = self.format_spotify_podcast(item, mood)
                            podcasts.append(podcast)
                            
                except Exception as e:
                    logger.error(f"Error fetching Spotify podcasts for {search_term}: {e}")
                    continue
            
            return podcasts[:5]
            
        except Exception as e:
            logger.error(f"Error in get_spotify_podcasts: {e}")
            return self.get_mock_podcasts(mood, language, genres)

    def get_ott_content(self, platform: str, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get OTT platform content (mock implementation)"""
        try:
            # Since OTT platforms don't have public APIs, use mock data
            platform_content = self.mock_ott_content.get(platform, {})
            mood_content = platform_content.get(mood, [])
            
            # Filter by language and genres
            filtered_content = []
            for content in mood_content:
                if (content.get('language', '').lower() == language.lower() or 
                    content.get('language', '').lower() == 'multi' or
                    language.lower() in content.get('available_languages', [])):
                    
                    if any(genre in content.get('genres', []) for genre in genres):
                        filtered_content.append(content)
            
            return filtered_content[:5]
            
        except Exception as e:
            logger.error(f"Error getting OTT content from {platform}: {e}")
            return []

    def get_indian_music(self, platform: str, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get music from Indian platforms (mock implementation)"""
        try:
            platform_content = self.mock_music_content.get(platform, {})
            mood_content = platform_content.get(mood, [])
            
            # Filter by language
            filtered_content = []
            for content in mood_content:
                if (content.get('language', '').lower() == language.lower() or 
                    content.get('language', '').lower() == 'multi'):
                    filtered_content.append(content)
            
            return filtered_content[:5]
            
        except Exception as e:
            logger.error(f"Error getting music from {platform}: {e}")
            return []

    def get_indian_podcasts(self, platform: str, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get podcasts from Indian platforms (mock implementation)"""
        # Return mock podcast data
        return self.get_mock_podcasts(mood, language, genres)

    def get_youtube_music(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get music from YouTube"""
        # Use YouTube video API with music-specific search terms
        music_genres = [f"{genre} music" for genre in genres]
        return self.get_youtube_videos(mood, language, music_genres)

    def get_youtube_podcasts(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Get podcasts from YouTube"""
        # Use YouTube video API with podcast-specific search terms
        podcast_genres = [f"{genre} podcast" for genre in genres]
        return self.get_youtube_videos(mood, language, podcast_genres)

    def build_search_terms(self, mood: str, language: str, genres: List[str], content_type: str) -> List[str]:
        """Build search terms based on mood, language, and content type"""
        terms = []
        
        # Language-specific mood terms
        mood_terms = {
            'hindi': {
                'happy': ['खुशी', 'खुश', 'प्रसन्न'],
                'excited': ['उत्साह', 'जोश'],
                'calm': ['शांत', 'आराम'],
                'stressed': ['तनाव मुक्त', 'रिलैक्स'],
                'sad': ['दुख भरा', 'उदास']
            },
            'tamil': {
                'happy': ['மகிழ்ச்சி', 'சந்தோஷம்'],
                'excited': ['உற்சாகம்'],
                'calm': ['அமைதி'],
                'stressed': ['நிம்மதி'],
                'sad': ['துக்கம்']
            },
            'telugu': {
                'happy': ['సంతోషం', 'ఆనందం'],
                'excited': ['ఉత్సాహం'],
                'calm': ['శాంతి'],
                'stressed': ['ప్రశాంతత'],
                'sad': ['దుఃఖం']
            },
            'english': {
                'happy': ['happy', 'joyful', 'cheerful'],
                'excited': ['exciting', 'energetic'],
                'calm': ['calm', 'peaceful', 'relaxing'],
                'stressed': ['stress relief', 'relaxing'],
                'sad': ['uplifting', 'motivational']
            }
        }
        
        lang_terms = mood_terms.get(language, mood_terms['english'])
        mood_specific_terms = lang_terms.get(mood, [mood])
        
        # Combine with genres and content type
        for mood_term in mood_specific_terms:
            for genre in genres:
                if content_type == 'music':
                    terms.append(f"{mood_term} {genre} songs {language}")
                elif content_type == 'video':
                    terms.append(f"{mood_term} {genre} videos {language}")
                elif content_type == 'podcast':
                    terms.append(f"{mood_term} {genre} podcast {language}")
        
        return terms[:5]  # Limit number of search terms

    def map_language_code(self, language: str) -> str:
        """Map language names to YouTube language codes"""
        mapping = {
            'hindi': 'hi',
            'tamil': 'ta',
            'telugu': 'te',
            'english': 'en'
        }
        return mapping.get(language, 'en')

    def format_youtube_video(self, item: Dict, mood: str) -> Dict:
        """Format YouTube video data"""
        return {
            'title': item['snippet']['title'],
            'description': item['snippet']['description'][:200] + '...',
            'platform': 'youtube',
            'type': 'video',
            'url': f"https://www.youtube.com/watch?v={item['id']['videoId']}",
            'thumbnail': item['snippet']['thumbnails'].get('medium', {}).get('url', ''),
            'channel': item['snippet']['channelTitle'],
            'published_at': item['snippet']['publishedAt'],
            'mood_match': mood,
            'language': 'multi'
        }

    def format_spotify_track(self, item: Dict, mood: str) -> Dict:
        """Format Spotify track data"""
        return {
            'title': item['name'],
            'description': f"by {', '.join([artist['name'] for artist in item['artists']])}",
            'platform': 'spotify',
            'type': 'music',
            'url': item['external_urls']['spotify'],
            'thumbnail': item['album']['images'][0]['url'] if item['album']['images'] else '',
            'artist': ', '.join([artist['name'] for artist in item['artists']]),
            'album': item['album']['name'],
            'mood_match': mood,
            'duration': item['duration_ms'],
            'language': 'multi'
        }

    def format_spotify_podcast(self, item: Dict, mood: str) -> Dict:
        """Format Spotify podcast data"""
        return {
            'title': item['name'],
            'description': item['description'][:200] + '...',
            'platform': 'spotify',
            'type': 'podcast',
            'url': item['external_urls']['spotify'],
            'thumbnail': item['images'][0]['url'] if item['images'] else '',
            'publisher': item['publisher'],
            'total_episodes': item['total_episodes'],
            'mood_match': mood,
            'language': 'multi'
        }

    def initialize_mock_ott_content(self) -> Dict:
        """Initialize mock OTT content for platforms without public APIs"""
        return {
            'jiohotstar': {
                'happy': [
                    {
                        'title': 'Comedy Nights with Indian Comedians',
                        'description': 'Best of Indian stand-up comedy to brighten your mood',
                        'platform': 'jiohotstar',
                        'type': 'video',
                        'genres': ['comedy', 'entertainment'],
                        'language': 'hindi',
                        'available_languages': ['hindi', 'english'],
                        'duration': '45 mins',
                        'rating': '4.5/5'
                    },
                    {
                        'title': 'Bollywood Dance Performances',
                        'description': 'Energetic Bollywood dance performances',
                        'platform': 'jiohotstar',
                        'type': 'video',
                        'genres': ['musical', 'dance'],
                        'language': 'hindi',
                        'available_languages': ['hindi'],
                        'duration': '30 mins',
                        'rating': '4.3/5'
                    }
                ],
                'calm': [
                    {
                        'title': 'Nature Documentaries India',
                        'description': 'Peaceful nature documentaries showcasing Indian wildlife',
                        'platform': 'jiohotstar',
                        'type': 'video',
                        'genres': ['documentary', 'nature'],
                        'language': 'hindi',
                        'available_languages': ['hindi', 'english'],
                        'duration': '60 mins',
                        'rating': '4.7/5'
                    }
                ],
                'stressed': [
                    {
                        'title': 'Yoga and Meditation Sessions',
                        'description': 'Guided yoga and meditation for stress relief',
                        'platform': 'jiohotstar',
                        'type': 'video',
                        'genres': ['wellness', 'meditation'],
                        'language': 'hindi',
                        'available_languages': ['hindi', 'english'],
                        'duration': '25 mins',
                        'rating': '4.6/5'
                    }
                ]
            },
            'zee5': {
                'happy': [
                    {
                        'title': 'Regional Comedy Shows',
                        'description': 'Comedy shows in multiple Indian languages',
                        'platform': 'zee5',
                        'type': 'video',
                        'genres': ['comedy', 'regional'],
                        'language': 'multi',
                        'available_languages': ['hindi', 'tamil', 'telugu'],
                        'duration': '40 mins',
                        'rating': '4.2/5'
                    }
                ],
                'calm': [
                    {
                        'title': 'Classical Music Concerts',
                        'description': 'Traditional Indian classical music performances',
                        'platform': 'zee5',
                        'type': 'video',
                        'genres': ['classical', 'music'],
                        'language': 'multi',
                        'available_languages': ['hindi', 'tamil', 'telugu'],
                        'duration': '90 mins',
                        'rating': '4.8/5'
                    }
                ]
            }
        }

    def initialize_mock_music_content(self) -> Dict:
        """Initialize mock music content for Indian platforms"""
        return {
            'jiosaavn': {
                'happy': [
                    {
                        'title': 'Bollywood Party Hits',
                        'description': 'Latest Bollywood party songs',
                        'platform': 'jiosaavn',
                        'type': 'music',
                        'language': 'hindi',
                        'genre': 'bollywood',
                        'duration': '3:45',
                        'artist': 'Various Artists'
                    },
                    {
                        'title': 'Tamil Celebration Songs',
                        'description': 'Upbeat Tamil movie songs',
                        'platform': 'jiosaavn',
                        'type': 'music',
                        'language': 'tamil',
                        'genre': 'tamil_cinema',
                        'duration': '4:12',
                        'artist': 'A.R. Rahman'
                    }
                ],
                'calm': [
                    {
                        'title': 'Peaceful Bhajans',
                        'description': 'Soothing devotional songs',
                        'platform': 'jiosaavn',
                        'type': 'music',
                        'language': 'hindi',
                        'genre': 'devotional',
                        'duration': '5:30',
                        'artist': 'Various Artists'
                    }
                ]
            },
            'gaana': {
                'happy': [
                    {
                        'title': 'Telugu Dance Numbers',
                        'description': 'Energetic Telugu movie dance songs',
                        'platform': 'gaana',
                        'type': 'music',
                        'language': 'telugu',
                        'genre': 'telugu_cinema',
                        'duration': '3:55',
                        'artist': 'Devi Sri Prasad'
                    }
                ],
                'stressed': [
                    {
                        'title': 'Relaxing Instrumentals',
                        'description': 'Calming instrumental music',
                        'platform': 'gaana',
                        'type': 'music',
                        'language': 'multi',
                        'genre': 'instrumental',
                        'duration': '6:20',
                        'artist': 'Hariprasad Chaurasia'
                    }
                ]
            }
        }

    def get_mock_youtube_videos(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Mock YouTube videos when API is not available"""
        return [
            {
                'title': f'{mood.title()} {language.title()} Content',
                'description': f'Sample {mood} content in {language} language',
                'platform': 'youtube',
                'type': 'video',
                'url': '#',
                'thumbnail': '',
                'channel': 'Sample Channel',
                'mood_match': mood,
                'language': language,
                'note': 'Sample data - YouTube API key required for real content'
            }
        ]

    def get_mock_spotify_music(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Mock Spotify music when API is not available"""
        return [
            {
                'title': f'{mood.title()} {language.title()} Songs',
                'description': f'Sample {mood} music in {language}',
                'platform': 'spotify',
                'type': 'music',
                'url': '#',
                'thumbnail': '',
                'artist': 'Sample Artist',
                'mood_match': mood,
                'language': language,
                'note': 'Sample data - Spotify API credentials required for real content'
            }
        ]

    def get_mock_podcasts(self, mood: str, language: str, genres: List[str]) -> List[Dict]:
        """Mock podcast content"""
        return [
            {
                'title': f'{mood.title()} {language.title()} Podcast',
                'description': f'Sample {mood} podcast in {language}',
                'platform': 'mock',
                'type': 'podcast',
                'url': '#',
                'thumbnail': '',
                'publisher': 'Sample Publisher',
                'mood_match': mood,
                'language': language,
                'note': 'Sample data - API credentials required for real content'
            }
        ]
