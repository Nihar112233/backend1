import logging
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional
import calendar

logger = logging.getLogger(__name__)

class CulturalContext:
    def __init__(self):
        """Initialize cultural context service for Indian festivals and events"""
        self.festivals = self.initialize_indian_festivals()
        self.regional_preferences = self.initialize_regional_preferences()
        self.cultural_mood_influences = self.initialize_cultural_mood_influences()

    def initialize_indian_festivals(self) -> Dict:
        """Initialize major Indian festivals with dates and cultural significance"""
        # Note: These are approximate dates. In reality, many Hindu festivals follow lunar calendar
        current_year = datetime.now().year
        
        festivals = {
            'diwali': {
                'name': 'Diwali',
                'date': date(current_year, 11, 12),  # Approximate
                'duration_days': 5,
                'regions': ['all'],
                'mood_influence': ['happy', 'excited', 'celebratory'],
                'content_boost': {
                    'music': ['devotional', 'festive', 'classical'],
                    'video': ['celebration', 'family', 'traditional'],
                    'genres': ['family', 'celebration', 'traditional']
                },
                'languages': ['hindi', 'tamil', 'telugu', 'gujarati', 'marathi']
            },
            'holi': {
                'name': 'Holi',
                'date': date(current_year, 3, 13),  # Approximate
                'duration_days': 2,
                'regions': ['north', 'west'],
                'mood_influence': ['happy', 'excited', 'joyful'],
                'content_boost': {
                    'music': ['holi_songs', 'bollywood', 'folk'],
                    'video': ['celebration', 'dance', 'colors'],
                    'genres': ['celebration', 'dance', 'folk']
                },
                'languages': ['hindi', 'punjabi', 'gujarati']
            },
            'dussehra': {
                'name': 'Dussehra',
                'date': date(current_year, 10, 15),  # Approximate
                'duration_days': 10,
                'regions': ['all'],
                'mood_influence': ['triumphant', 'excited', 'devotional'],
                'content_boost': {
                    'music': ['devotional', 'classical', 'victory_songs'],
                    'video': ['mythology', 'victory', 'traditional'],
                    'genres': ['mythology', 'traditional', 'devotional']
                },
                'languages': ['hindi', 'tamil', 'telugu', 'kannada']
            },
            'eid': {
                'name': 'Eid ul-Fitr',
                'date': date(current_year, 4, 21),  # Approximate
                'duration_days': 3,
                'regions': ['all'],
                'mood_influence': ['happy', 'peaceful', 'grateful'],
                'content_boost': {
                    'music': ['qawwali', 'sufi', 'celebration'],
                    'video': ['family', 'celebration', 'unity'],
                    'genres': ['family', 'celebration', 'sufi']
                },
                'languages': ['urdu', 'hindi', 'bengali']
            },
            'navratri': {
                'name': 'Navratri',
                'date': date(current_year, 10, 3),  # Approximate
                'duration_days': 9,
                'regions': ['west', 'north'],
                'mood_influence': ['energetic', 'devotional', 'dance'],
                'content_boost': {
                    'music': ['garba', 'devotional', 'folk_dance'],
                    'video': ['dance', 'devotional', 'traditional'],
                    'genres': ['dance', 'devotional', 'folk']
                },
                'languages': ['gujarati', 'hindi', 'marathi']
            },
            'pongal': {
                'name': 'Pongal',
                'date': date(current_year, 1, 14),
                'duration_days': 4,
                'regions': ['south'],
                'mood_influence': ['grateful', 'happy', 'harvest_joy'],
                'content_boost': {
                    'music': ['tamil_folk', 'harvest_songs', 'traditional'],
                    'video': ['harvest', 'family', 'tradition'],
                    'genres': ['harvest', 'family', 'traditional']
                },
                'languages': ['tamil']
            },
            'onam': {
                'name': 'Onam',
                'date': date(current_year, 8, 31),  # Approximate
                'duration_days': 10,
                'regions': ['south'],
                'mood_influence': ['happy', 'nostalgic', 'cultural_pride'],
                'content_boost': {
                    'music': ['malayalam_folk', 'traditional', 'classical'],
                    'video': ['cultural', 'tradition', 'harvest'],
                    'genres': ['cultural', 'traditional', 'folk']
                },
                'languages': ['malayalam']
            },
            'ganesh_chaturthi': {
                'name': 'Ganesh Chaturthi',
                'date': date(current_year, 9, 7),  # Approximate
                'duration_days': 11,
                'regions': ['west', 'south'],
                'mood_influence': ['devotional', 'excited', 'community'],
                'content_boost': {
                    'music': ['ganesh_songs', 'devotional', 'marathi_folk'],
                    'video': ['devotional', 'community', 'celebration'],
                    'genres': ['devotional', 'community', 'traditional']
                },
                'languages': ['marathi', 'hindi', 'telugu']
            }
        }
        
        return festivals

    def initialize_regional_preferences(self) -> Dict:
        """Initialize regional content preferences"""
        return {
            'north': {
                'primary_languages': ['hindi', 'punjabi', 'urdu'],
                'music_preferences': ['bollywood', 'punjabi_pop', 'classical', 'qawwali'],
                'content_preferences': ['bollywood', 'punjabi_cinema', 'historical'],
                'cultural_elements': ['bollywood_dance', 'punjabi_culture', 'mughal_history']
            },
            'south': {
                'primary_languages': ['tamil', 'telugu', 'kannada', 'malayalam'],
                'music_preferences': ['south_indian_classical', 'film_music', 'folk'],
                'content_preferences': ['regional_cinema', 'classical_arts', 'mythology'],
                'cultural_elements': ['classical_dance', 'temple_culture', 'traditional_arts']
            },
            'west': {
                'primary_languages': ['gujarati', 'marathi', 'hindi'],
                'music_preferences': ['folk', 'garba', 'classical', 'bollywood'],
                'content_preferences': ['regional_theater', 'business_content', 'cultural'],
                'cultural_elements': ['business_culture', 'folk_dance', 'traditional_arts']
            },
            'east': {
                'primary_languages': ['bengali', 'odia', 'assamese'],
                'music_preferences': ['rabindra_sangeet', 'folk', 'classical'],
                'content_preferences': ['art_films', 'literature', 'cultural'],
                'cultural_elements': ['intellectual_culture', 'arts', 'literature']
            }
        }

    def initialize_cultural_mood_influences(self) -> Dict:
        """Initialize how cultural events influence mood recommendations"""
        return {
            'monsoon_season': {
                'months': [6, 7, 8, 9],  # June to September
                'mood_influence': {
                    'calm': 1.3,  # Boost calm content during monsoons
                    'romantic': 1.2,  # Monsoon romance
                    'nostalgic': 1.2
                },
                'content_boost': ['rain_songs', 'romantic', 'cozy', 'indoor_activities']
            },
            'winter_season': {
                'months': [12, 1, 2],  # December to February
                'mood_influence': {
                    'warm': 1.2,
                    'family': 1.3,
                    'cozy': 1.3
                },
                'content_boost': ['family_content', 'warm_music', 'indoor_entertainment']
            },
            'summer_season': {
                'months': [3, 4, 5],  # March to May
                'mood_influence': {
                    'refreshing': 1.3,
                    'cool': 1.2,
                    'energetic': 0.8  # Slightly less energetic content in heat
                },
                'content_boost': ['cool_music', 'refreshing_content', 'indoor_activities']
            },
            'wedding_season': {
                'months': [11, 12, 1, 2],  # Winter months
                'mood_influence': {
                    'celebratory': 1.4,
                    'romantic': 1.3,
                    'family': 1.3
                },
                'content_boost': ['wedding_songs', 'romantic', 'celebration', 'family']
            }
        }

    def get_current_events(self) -> List[Dict]:
        """Get current cultural events and festivals"""
        try:
            current_date = date.today()
            current_events = []
            
            # Check for ongoing festivals
            for festival_id, festival in self.festivals.items():
                festival_date = festival['date']
                duration = festival.get('duration_days', 1)
                
                # Check if festival is currently happening or approaching (within 7 days)
                start_date = festival_date
                end_date = festival_date + timedelta(days=duration)
                approach_date = festival_date - timedelta(days=7)
                
                if approach_date <= current_date <= end_date:
                    status = 'ongoing' if start_date <= current_date <= end_date else 'approaching'
                    
                    current_events.append({
                        'id': festival_id,
                        'name': festival['name'],
                        'date': festival_date.isoformat(),
                        'status': status,
                        'days_until': (festival_date - current_date).days if current_date < festival_date else 0,
                        'mood_influence': festival['mood_influence'],
                        'content_boost': festival['content_boost'],
                        'regions': festival['regions'],
                        'languages': festival['languages']
                    })
            
            # Check for seasonal influences
            current_month = current_date.month
            for season_id, season in self.cultural_mood_influences.items():
                if current_month in season.get('months', []):
                    current_events.append({
                        'id': season_id,
                        'name': season_id.replace('_', ' ').title(),
                        'type': 'seasonal',
                        'status': 'ongoing',
                        'mood_influence': season['mood_influence'],
                        'content_boost': season['content_boost']
                    })
            
            return current_events
            
        except Exception as e:
            logger.error(f"Error getting current events: {e}")
            return []

    def get_cultural_boosts(self, language: str, region: Optional[str] = None) -> Dict:
        """Get cultural content boosts based on current events and preferences"""
        try:
            boosts = {
                'festival_boost': [],
                'seasonal_boost': [],
                'regional_preference': [],
                'language_boost': language
            }
            
            current_events = self.get_current_events()
            
            # Apply festival boosts
            for event in current_events:
                if event.get('type') != 'seasonal':
                    # Check if language is supported by this festival
                    if language in event.get('languages', []):
                        boosts['festival_boost'].extend(event.get('content_boost', {}).get('music', []))
                        boosts['festival_boost'].extend(event.get('content_boost', {}).get('video', []))
                else:
                    # Seasonal boosts
                    boosts['seasonal_boost'].extend(event.get('content_boost', []))
            
            # Apply regional preferences
            if region:
                regional_prefs = self.regional_preferences.get(region, {})
                boosts['regional_preference'] = regional_prefs.get('primary_languages', [])
                boosts['music_preferences'] = regional_prefs.get('music_preferences', [])
                boosts['content_preferences'] = regional_prefs.get('content_preferences', [])
            
            return boosts
            
        except Exception as e:
            logger.error(f"Error getting cultural boosts: {e}")
            return {'festival_boost': [], 'seasonal_boost': [], 'regional_preference': []}

    def get_festival_specific_content(self, festival_name: str, content_type: str) -> List[str]:
        """Get specific content recommendations for a festival"""
        try:
            for festival in self.festivals.values():
                if festival['name'].lower() == festival_name.lower():
                    return festival.get('content_boost', {}).get(content_type, [])
            return []
            
        except Exception as e:
            logger.error(f"Error getting festival content for {festival_name}: {e}")
            return []

    def is_auspicious_time(self, current_time: Optional[datetime] = None) -> Dict:
        """Check if current time is considered auspicious in Indian culture"""
        try:
            if not current_time:
                current_time = datetime.now()
            
            hour = current_time.hour
            day_of_week = current_time.weekday()  # 0 = Monday
            
            # Traditional auspicious times
            auspicious_hours = {
                'brahma_muhurta': (4, 6),  # 4 AM to 6 AM
                'morning_prayers': (6, 8),  # 6 AM to 8 AM
                'evening_prayers': (18, 20)  # 6 PM to 8 PM
            }
            
            # Check if current hour falls in auspicious time
            current_auspicious = []
            for period, (start, end) in auspicious_hours.items():
                if start <= hour < end:
                    current_auspicious.append(period)
            
            # Special considerations for days
            special_days = {
                0: 'monday_shiva',  # Monday - good for Shiva worship
                3: 'thursday_guru',  # Thursday - good for learning
                4: 'friday_devi',   # Friday - good for Devi worship
                6: 'sunday_surya'   # Sunday - good for Surya worship
            }
            
            return {
                'is_auspicious': bool(current_auspicious),
                'auspicious_periods': current_auspicious,
                'special_day': special_days.get(day_of_week),
                'content_recommendations': {
                    'brahma_muhurta': ['meditation', 'spiritual', 'classical'],
                    'morning_prayers': ['devotional', 'peaceful', 'spiritual'],
                    'evening_prayers': ['devotional', 'family', 'traditional']
                }
            }
            
        except Exception as e:
            logger.error(f"Error checking auspicious time: {e}")
            return {'is_auspicious': False, 'auspicious_periods': [], 'special_day': None}

    def get_mood_cultural_enhancement(self, mood: str, language: str) -> Dict:
        """Enhance mood analysis with cultural context"""
        try:
            cultural_enhancement = {
                'cultural_mood_terms': [],
                'enhanced_recommendations': [],
                'cultural_activities': [],
                'traditional_remedies': []
            }
            
            # Cultural mood enhancement based on language and traditions
            cultural_mood_mappings = {
                'hindi': {
                    'stressed': {
                        'terms': ['तनाव मुक्ति', 'शांति', 'योग'],
                        'recommendations': ['yoga_videos', 'meditation', 'bhajans', 'classical_music'],
                        'activities': ['प्राणायाम', 'ध्यान', 'मंत्र जाप'],
                        'remedies': ['गरम दूध', 'तुलसी चाय', 'ध्यान']
                    },
                    'happy': {
                        'terms': ['खुशी', 'आनंद', 'उत्सव'],
                        'recommendations': ['bollywood_songs', 'comedy', 'dance_videos'],
                        'activities': ['नृत्य', 'गाना', 'मित्रों के साथ समय'],
                        'remedies': ['मिठाई', 'संगीत', 'उत्सव']
                    }
                },
                'tamil': {
                    'stressed': {
                        'terms': ['அமைதி', 'நிம்மதி', 'யோகா'],
                        'recommendations': ['carnatic_music', 'temple_videos', 'nature_sounds'],
                        'activities': ['யோகா', 'தியானம்', 'இசை கேட்டல்'],
                        'remedies': ['துளசி தேநீர்', 'தியானம்', 'இயற்கை ஒலி']
                    },
                    'happy': {
                        'terms': ['மகிழ்ச்சி', 'சந்தோஷம்', 'ஆனந்தம்'],
                        'recommendations': ['tamil_songs', 'comedy', 'classical_dance'],
                        'activities': ['நாட்டுப்புற பாடல்கள்', 'கோயில் விஜயம்'],
                        'remedies': ['இனிப்பு', 'இசை', 'நண்பர்களுடன் நேரம்']
                    }
                },
                'telugu': {
                    'stressed': {
                        'terms': ['శాంతి', 'ప్రశాంతత', 'యోగా'],
                        'recommendations': ['classical_music', 'spiritual_videos', 'nature_content'],
                        'activities': ['యోగా', 'ధ్యానం', 'భజనలు'],
                        'remedies': ['హల్దీ పాలు', 'ధ్యానం', 'ప్రకృతి శబ్దాలు']
                    },
                    'happy': {
                        'terms': ['సంతోషం', 'ఆనందం', 'ఉత్సవం'],
                        'recommendations': ['telugu_songs', 'comedy', 'dance_performances'],
                        'activities': ['నృత్యం', 'పాటలు', 'కుటుంబంతో సమయం'],
                        'remedies': ['తియ్యని వంటకాలు', 'సంగీతం', 'ఉత్సవాలు']
                    }
                }
            }
            
            lang_mappings = cultural_mood_mappings.get(language, {})
            mood_mapping = lang_mappings.get(mood, {})
            
            cultural_enhancement.update({
                'cultural_mood_terms': mood_mapping.get('terms', []),
                'enhanced_recommendations': mood_mapping.get('recommendations', []),
                'cultural_activities': mood_mapping.get('activities', []),
                'traditional_remedies': mood_mapping.get('remedies', [])
            })
            
            return cultural_enhancement
            
        except Exception as e:
            logger.error(f"Error getting cultural mood enhancement: {e}")
            return {
                'cultural_mood_terms': [],
                'enhanced_recommendations': [],
                'cultural_activities': [],
                'traditional_remedies': []
            }
