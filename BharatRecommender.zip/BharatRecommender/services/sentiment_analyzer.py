import logging
import re
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class SentimentAnalyzer:
    def __init__(self):
        """Initialize sentiment analyzer with keyword-based approach for Indian languages"""
        try:
            # Cultural mood mappings for different Indian languages
            self.cultural_moods = {
                'hindi': {
                    'उत्साह': 'excited', 'खुशी': 'happy', 'आनंद': 'joyful',
                    'शांति': 'calm', 'सुकून': 'peaceful', 'विश्रांति': 'relaxed',
                    'तनाव': 'stressed', 'चिंता': 'worried', 'परेशानी': 'troubled',
                    'उदास': 'sad', 'दुख': 'sorrowful', 'निराश': 'disappointed',
                    'गुस्सा': 'angry', 'क्रोध': 'furious', 'चिढ़': 'irritated',
                    'प्रेम': 'loving', 'प्यार': 'affectionate', 'स्नेह': 'caring',
                    'डर': 'fearful', 'भय': 'scared', 'घबराहट': 'anxious'
                },
                'tamil': {
                    'சந்தோஷம்': 'happy', 'மகிழ்ச்சி': 'joyful', 'உற்சாகம்': 'excited',
                    'அமைதி': 'calm', 'நிம்மதி': 'peaceful', 'ஓய்வு': 'relaxed',
                    'கவலை': 'worried', 'பதற்றம்': 'stressed', 'துக்கம்': 'sad',
                    'கோபம்': 'angry', 'அன்பு': 'loving', 'பயம்': 'fearful'
                },
                'telugu': {
                    'సంతోషం': 'happy', 'ఆనందం': 'joyful', 'ఉత్సాహం': 'excited',
                    'శాంతి': 'calm', 'నిమ్మదిగా': 'peaceful', 'విశ్రాంతి': 'relaxed',
                    'ఆందోళన': 'worried', 'టెన్షన్': 'stressed', 'దుఃఖం': 'sad',
                    'కోపం': 'angry', 'ప్రేమ': 'loving', 'భయం': 'fearful'
                },
                'english': {
                    'happy': 'happy', 'joy': 'joyful', 'excited': 'excited',
                    'calm': 'calm', 'peaceful': 'peaceful', 'relaxed': 'relaxed',
                    'worried': 'worried', 'stressed': 'stressed', 'sad': 'sad',
                    'angry': 'angry', 'love': 'loving', 'fear': 'fearful'
                }
            }
            
            # Sentiment scoring patterns for different languages
            self.sentiment_patterns = {
                'positive': {
                    'hindi': ['खुश', 'अच्छा', 'बेहतरीन', 'शानदार', 'उत्साह', 'आनंद', 'प्रसन्न'],
                    'tamil': ['மகிழ்ச்சி', 'நல்ல', 'அருமை', 'சந்தோஷம்', 'உற்சாகம்'],
                    'telugu': ['సంతోషం', 'మంచి', 'అద్భుతం', 'ఆనందం', 'ఉత్సాహం'],
                    'english': ['happy', 'good', 'great', 'awesome', 'excited', 'joy', 'wonderful']
                },
                'negative': {
                    'hindi': ['उदास', 'दुख', 'गुस्सा', 'तनाव', 'परेशान', 'निराश', 'चिंता'],
                    'tamil': ['துக்கம்', 'கோபம்', 'கவலை', 'பதற்றம்', 'வருத்தம்'],
                    'telugu': ['దుఃఖం', 'కోపం', 'ఆందోళన', 'టెన్షన్', 'బాధ'],
                    'english': ['sad', 'angry', 'worried', 'stressed', 'upset', 'disappointed', 'anxious']
                },
                'neutral': {
                    'hindi': ['ठीक', 'सामान्य', 'शांत', 'ऐसे ही'],
                    'tamil': ['சரி', 'சாதாரண', 'அமைதி'],
                    'telugu': ['బాగా', 'సాధారణ', 'శాంతి'],
                    'english': ['okay', 'normal', 'fine', 'calm', 'neutral']
                }
            }
            
            # Mood categories mapping
            self.mood_categories = {
                'happy': ['joyful', 'excited', 'cheerful', 'elated', 'blissful'],
                'calm': ['peaceful', 'relaxed', 'serene', 'tranquil', 'composed'],
                'energetic': ['excited', 'enthusiastic', 'motivated', 'inspired', 'dynamic'],
                'stressed': ['anxious', 'worried', 'overwhelmed', 'tense', 'pressured'],
                'sad': ['melancholy', 'sorrowful', 'downhearted', 'dejected', 'gloomy'],
                'angry': ['furious', 'irritated', 'frustrated', 'annoyed', 'agitated'],
                'loving': ['affectionate', 'caring', 'tender', 'warm', 'compassionate'],
                'fearful': ['scared', 'nervous', 'apprehensive', 'timid', 'uneasy'],
                'neutral': ['balanced', 'steady', 'stable', 'indifferent', 'detached']
            }
            
            logger.info("Sentiment analyzer initialized successfully")
            
        except Exception as e:
            logger.error(f"Error initializing sentiment analyzer: {e}")
            # Continue with basic functionality even if initialization fails
    
    def analyze_mood(self, text: str, language: str = 'hindi') -> Dict:
        """
        Analyze mood from text input using keyword-based approach
        
        Args:
            text: Input text to analyze
            language: Language of the input text
            
        Returns:
            Dictionary with mood analysis results
        """
        try:
            if not text or not text.strip():
                return self._get_default_mood_result()
            
            text = text.lower().strip()
            
            # First try to find direct mood mappings
            direct_mood = self._find_direct_mood_mapping(text, language)
            if direct_mood:
                return self._create_mood_result(direct_mood, 0.9, text, language)
            
            # Use keyword-based sentiment analysis
            sentiment_scores = self._calculate_sentiment_scores(text, language)
            primary_mood = self._determine_primary_mood(sentiment_scores)
            confidence = max(sentiment_scores.values()) if sentiment_scores else 0.5
            
            return self._create_mood_result(primary_mood, confidence, text, language)
            
        except Exception as e:
            logger.error(f"Error in mood analysis: {e}")
            return self._get_default_mood_result()
    
    def _find_direct_mood_mapping(self, text: str, language: str) -> Optional[str]:
        """Find direct mood mapping from cultural mood dictionaries"""
        if language not in self.cultural_moods:
            language = 'english'  # fallback
        
        mood_dict = self.cultural_moods[language]
        for word, mood in mood_dict.items():
            if word.lower() in text:
                return mood
        return None
    
    def _calculate_sentiment_scores(self, text: str, language: str) -> Dict[str, float]:
        """Calculate sentiment scores based on keyword matching"""
        scores = {'positive': 0.0, 'negative': 0.0, 'neutral': 0.0}
        
        if language not in self.sentiment_patterns['positive']:
            language = 'english'  # fallback
        
        # Count positive keywords
        positive_words = self.sentiment_patterns['positive'][language]
        for word in positive_words:
            if word.lower() in text:
                scores['positive'] += 1
        
        # Count negative keywords
        negative_words = self.sentiment_patterns['negative'][language]
        for word in negative_words:
            if word.lower() in text:
                scores['negative'] += 1
        
        # Count neutral keywords
        neutral_words = self.sentiment_patterns['neutral'][language]
        for word in neutral_words:
            if word.lower() in text:
                scores['neutral'] += 1
        
        # Normalize scores
        total = sum(scores.values())
        if total > 0:
            scores = {k: v/total for k, v in scores.items()}
        else:
            scores = {'positive': 0.3, 'negative': 0.3, 'neutral': 0.4}  # default
        
        return scores
    
    def _determine_primary_mood(self, sentiment_scores: Dict[str, float]) -> str:
        """Determine primary mood based on sentiment scores"""
        if not sentiment_scores:
            return 'neutral'
        
        # Find the dominant sentiment
        dominant_sentiment = max(sentiment_scores.keys(), key=lambda x: sentiment_scores[x])
        
        # Map sentiment to mood
        if dominant_sentiment == 'positive':
            return 'happy'
        elif dominant_sentiment == 'negative':
            return 'sad'
        else:
            return 'neutral'
    
    def _create_mood_result(self, mood: str, confidence: float, text: str, language: str) -> Dict:
        """Create structured mood analysis result"""
        return {
            'primary_mood': mood,
            'confidence': confidence,
            'sentiment_scores': {
                'positive': 0.7 if mood in ['happy', 'joyful', 'excited'] else 0.2,
                'negative': 0.7 if mood in ['sad', 'angry', 'stressed'] else 0.2,
                'neutral': 0.7 if mood == 'neutral' else 0.1
            },
            'mood_intensity': confidence,
            'detected_language': language,
            'cultural_context': self._get_cultural_context(mood, language),
            'related_moods': self._get_related_moods(mood),
            'input_analysis': {
                'text_length': len(text),
                'language': language,
                'processing_method': 'keyword_based'
            }
        }
    
    def _get_cultural_context(self, mood: str, language: str) -> Dict:
        """Get cultural context for the detected mood"""
        context = {
            'cultural_significance': True,
            'regional_relevance': language,
            'festival_alignment': [],
            'content_preferences': []
        }
        
        # Add mood-specific cultural context
        if mood in ['happy', 'joyful']:
            context['festival_alignment'] = ['Diwali', 'Holi', 'Navratri']
            context['content_preferences'] = ['celebration', 'music', 'dance']
        elif mood in ['peaceful', 'calm']:
            context['festival_alignment'] = ['Buddha Purnima', 'Guru Nanak Jayanti']
            context['content_preferences'] = ['meditation', 'spiritual', 'classical']
        elif mood in ['loving', 'affectionate']:
            context['festival_alignment'] = ['Karva Chauth', 'Valentine\'s Day']
            context['content_preferences'] = ['romance', 'family', 'devotional']
        
        return context
    
    def _get_related_moods(self, primary_mood: str) -> List[str]:
        """Get related moods for the primary mood"""
        if primary_mood in self.mood_categories:
            return self.mood_categories[primary_mood][:3]  # Return top 3 related moods
        return [primary_mood]
    
    def _get_default_mood_result(self) -> Dict:
        """Return default mood result when analysis fails"""
        return {
            'primary_mood': 'neutral',
            'confidence': 0.5,
            'sentiment_scores': {'positive': 0.3, 'negative': 0.3, 'neutral': 0.4},
            'mood_intensity': 0.5,
            'detected_language': 'hindi',
            'cultural_context': {'cultural_significance': False},
            'related_moods': ['neutral', 'calm'],
            'input_analysis': {'processing_method': 'default_fallback'}
        }
    
    def get_mood_suggestions(self, language: str = 'hindi') -> Dict:
        """Get mood suggestions categorized by type"""
        suggestions = {
            'positive_moods': {
                'hindi': ['खुश', 'उत्साहित', 'आनंदित', 'प्रसन्न'],
                'tamil': ['மகிழ்ச்சி', 'உற்சாகம்', 'சந்தோஷம்', 'மகிழ்வு'],
                'telugu': ['సంతోషం', 'ఉత్సాహం', 'ఆనందం', 'ప్రసన్నత'],
                'english': ['happy', 'excited', 'joyful', 'cheerful']
            },
            'calm_moods': {
                'hindi': ['शांत', 'सुकून', 'आराम', 'निश्चिंत'],
                'tamil': ['அமைதி', 'நிம்மதி', 'ஓய்வு', 'மனநிम்மதி'],
                'telugu': ['శాంతి', 'నిమ్మదిగా', 'విశ్రాంతి', 'ప్రశాంతత'],
                'english': ['calm', 'peaceful', 'relaxed', 'serene']
            },
            'negative_moods': {
                'hindi': ['उदास', 'तनाव', 'चिंता', 'परेशान'],
                'tamil': ['துக்கம்', 'கவலை', 'பதற்றம்', 'வருத்தம்'],
                'telugu': ['దుఃఖం', 'ఆందోళన', 'టెన్షన్', 'బాధ'],
                'english': ['sad', 'stressed', 'worried', 'upset']
            }
        }
        
        return suggestions.get(language, suggestions['english'])

# Create global instance
sentiment_analyzer = SentimentAnalyzer()