# replit.md

## Overview

MoodConnect is a Flask-based AI-powered content recommendation system designed specifically for Indian users. The application analyzes user mood through text input in multiple Indian languages (Hindi, Tamil, Telugu) and provides personalized content recommendations for various platforms including OTT services, music streaming, podcasts, and books. The system incorporates cultural awareness, understanding Indian festivals and regional preferences to enhance recommendation quality.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Backend Architecture
- **Framework**: Flask with SQLAlchemy ORM
- **Database**: SQLite with plans for PostgreSQL migration
- **AI/ML**: Transformers library with IndicBERT for sentiment analysis
- **Translation**: Google Translate for multi-language support
- **Caching**: Simple file-based caching system

### Frontend Architecture
- **Template Engine**: Jinja2 with Bootstrap 5 for responsive UI
- **Styling**: Custom CSS with Indian cultural themes
- **JavaScript**: Vanilla JavaScript for client-side interactions
- **Icons**: Feather Icons for consistent UI elements

### API Integrations
- **YouTube API**: For video content recommendations
- **Spotify API**: For music recommendations
- **Mock APIs**: For OTT platforms without public APIs

## Key Components

### Core Services
1. **Sentiment Analyzer** (`services/sentiment_analyzer.py`)
   - Uses IndicBERT model for Indian language sentiment analysis
   - Supports Hindi, Tamil, Telugu with cultural mood mappings
   - Handles mood intensity detection and cultural context

2. **Content Recommender** (`services/content_recommender.py`)
   - Mood-based content matching algorithm
   - Platform-specific recommendation logic
   - Cultural event-aware recommendations

3. **Cultural Context** (`services/cultural_context.py`)
   - Indian festival tracking and awareness
   - Regional preference handling
   - Cultural mood influence analysis

4. **API Integrations** (`services/api_integrations.py`)
   - External platform API management
   - Mock data for platforms without APIs
   - Rate limiting and error handling

### Database Models
- **User**: User profiles with language and regional preferences
- **MoodHistory**: Track user mood patterns over time
- **Content**: Content metadata with cultural tags
- **Recommendation**: Recommendation history with confidence scores
- **UserPreference**: Platform and genre preferences

### Utilities
- **Cache System** (`utils/cache.py`): File-based caching for API responses
- **Helpers** (`utils/helpers.py`): User session management and utility functions

## Data Flow

1. **User Input**: User selects language and inputs mood description
2. **Sentiment Analysis**: IndicBERT processes text for mood detection
3. **Cultural Context**: System checks for current festivals/events
4. **Content Matching**: Algorithm matches mood to content types and genres
5. **API Calls**: External APIs fetched for real-time content
6. **Recommendation Generation**: Personalized recommendations with confidence scores
7. **User Feedback**: Track user interactions for improvement

## External Dependencies

### AI/ML Libraries
- `transformers`: IndicBERT model for sentiment analysis
- `torch`: PyTorch backend for transformers
- `googletrans`: Multi-language translation support

### Web Framework
- `Flask`: Core web framework
- `Flask-SQLAlchemy`: Database ORM
- `Jinja2`: Template rendering

### External APIs
- **YouTube Data API v3**: Video content discovery
- **Spotify Web API**: Music recommendations
- **Mock APIs**: For Netflix, Amazon Prime, Hotstar content

### Frontend Dependencies
- **Bootstrap 5**: Responsive UI framework
- **Feather Icons**: Icon library
- **Chart.js**: Data visualization
- **Custom CSS**: Indian cultural theme implementation

## Deployment Strategy

### Development Environment
- Local SQLite database for rapid development
- Environment variables for API keys
- Debug mode enabled for development

### Production Considerations
- **Database**: Migration to PostgreSQL recommended
- **Caching**: Redis implementation for better performance
- **API Management**: Rate limiting and authentication
- **Security**: Environment-based configuration management
- **Scalability**: Container-ready architecture

### Environment Variables Required
- `DATABASE_URL`: Database connection string
- `SESSION_SECRET`: Flask session security key
- `YOUTUBE_API_KEY`: YouTube Data API access
- `SPOTIFY_CLIENT_ID`: Spotify API client ID
- `SPOTIFY_CLIENT_SECRET`: Spotify API secret

### File Structure Organization
- `app.py`: Application factory and configuration
- `main.py`: Entry point for development server
- `models.py`: Database schema definitions
- `routes.py`: URL routing and view functions
- `services/`: Business logic and external integrations
- `templates/`: HTML templates with multi-language support
- `static/`: CSS, JavaScript, and asset files
- `utils/`: Helper functions and utilities

The application follows a modular architecture with clear separation of concerns, making it maintainable and scalable for Indian content recommendation scenarios.