import logging
import json
import os
from datetime import datetime, timedelta
from typing import Dict, Optional
import hashlib

logger = logging.getLogger(__name__)

class SimpleCache:
    """Simple file-based cache implementation"""
    
    def __init__(self, cache_dir: str = "cache", default_timeout: int = 3600):
        """Initialize cache with directory and default timeout"""
        self.cache_dir = cache_dir
        self.default_timeout = default_timeout
        
        # Create cache directory if it doesn't exist
        if not os.path.exists(cache_dir):
            os.makedirs(cache_dir)

    def _get_cache_filename(self, key: str) -> str:
        """Generate cache filename from key"""
        # Create a safe filename from the key
        key_hash = hashlib.md5(key.encode()).hexdigest()
        return os.path.join(self.cache_dir, f"cache_{key_hash}.json")

    def _is_expired(self, cache_data: Dict) -> bool:
        """Check if cached data has expired"""
        try:
            expiry_time = datetime.fromisoformat(cache_data.get('expiry', ''))
            return datetime.utcnow() > expiry_time
        except (ValueError, TypeError):
            return True

    def get(self, key: str) -> Optional[Dict]:
        """Get value from cache"""
        try:
            cache_file = self._get_cache_filename(key)
            
            if not os.path.exists(cache_file):
                return None
            
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            
            if self._is_expired(cache_data):
                # Clean up expired cache
                self.delete(key)
                return None
            
            logger.debug(f"Cache hit for key: {key}")
            return cache_data.get('value')
            
        except Exception as e:
            logger.error(f"Error reading from cache for key {key}: {e}")
            return None

    def set(self, key: str, value: Dict, timeout: Optional[int] = None) -> bool:
        """Set value in cache"""
        try:
            cache_file = self._get_cache_filename(key)
            timeout = timeout or self.default_timeout
            
            expiry_time = datetime.utcnow() + timedelta(seconds=timeout)
            
            cache_data = {
                'value': value,
                'expiry': expiry_time.isoformat(),
                'created': datetime.utcnow().isoformat()
            }
            
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, indent=2, ensure_ascii=False)
            
            logger.debug(f"Cache set for key: {key}")
            return True
            
        except Exception as e:
            logger.error(f"Error writing to cache for key {key}: {e}")
            return False

    def delete(self, key: str) -> bool:
        """Delete value from cache"""
        try:
            cache_file = self._get_cache_filename(key)
            
            if os.path.exists(cache_file):
                os.remove(cache_file)
                logger.debug(f"Cache deleted for key: {key}")
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Error deleting cache for key {key}: {e}")
            return False

    def clear(self) -> bool:
        """Clear all cache files"""
        try:
            for filename in os.listdir(self.cache_dir):
                if filename.startswith('cache_') and filename.endswith('.json'):
                    file_path = os.path.join(self.cache_dir, filename)
                    os.remove(file_path)
            
            logger.info("Cache cleared successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error clearing cache: {e}")
            return False

    def cleanup_expired(self) -> int:
        """Clean up expired cache entries"""
        try:
            cleaned = 0
            for filename in os.listdir(self.cache_dir):
                if filename.startswith('cache_') and filename.endswith('.json'):
                    file_path = os.path.join(self.cache_dir, filename)
                    
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            cache_data = json.load(f)
                        
                        if self._is_expired(cache_data):
                            os.remove(file_path)
                            cleaned += 1
                            
                    except Exception:
                        # If we can't read the file, consider it corrupted and remove it
                        os.remove(file_path)
                        cleaned += 1
            
            logger.info(f"Cleaned up {cleaned} expired cache entries")
            return cleaned
            
        except Exception as e:
            logger.error(f"Error cleaning up expired cache: {e}")
            return 0

# Global cache instance
_cache = SimpleCache()

def get_cached_recommendations(key: str) -> Optional[Dict]:
    """Get cached recommendations"""
    return _cache.get(f"recommendations_{key}")

def cache_recommendations(key: str, data: Dict, timeout: int = 1800) -> bool:
    """Cache recommendations for 30 minutes by default"""
    return _cache.set(f"recommendations_{key}", data, timeout)

def get_cached_api_response(key: str) -> Optional[Dict]:
    """Get cached API response"""
    return _cache.get(f"api_{key}")

def cache_api_response(key: str, data: Dict, timeout: int = 600) -> bool:
    """Cache API response for 10 minutes by default"""
    return _cache.set(f"api_{key}", data, timeout)

def get_cached_sentiment_analysis(key: str) -> Optional[Dict]:
    """Get cached sentiment analysis"""
    return _cache.get(f"sentiment_{key}")

def cache_sentiment_analysis(key: str, data: Dict, timeout: int = 3600) -> bool:
    """Cache sentiment analysis for 1 hour"""
    return _cache.set(f"sentiment_{key}", data, timeout)

def clear_all_cache() -> bool:
    """Clear all cached data"""
    return _cache.clear()

def cleanup_expired_cache() -> int:
    """Clean up expired cache entries"""
    return _cache.cleanup_expired()
