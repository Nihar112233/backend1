import logging
from datetime import datetime, date
from typing import Optional, Dict, List
from flask import session, request
from models import User
from app import db
import hashlib
import re

logger = logging.getLogger(__name__)

def get_current_user() -> Optional[User]:
    """Get current user from session"""
    try:
        user_id = session.get('user_id')
        if user_id:
            return User.query.get(user_id)
        
        # If no user session, create a temporary user or return None
        return None
        
    except Exception as e:
        logger.error(f"Error getting current user: {e}")
        return None

def create_user_session(user: User) -> bool:
    """Create user session"""
    try:
        session['user_id'] = user.id
        session['username'] = user.username
        session['preferred_language'] = user.preferred_language
        session.permanent = True
        return True
        
    except Exception as e:
        logger.error(f"Error creating user session: {e}")
        return False

def get_user_preferences(user: Optional[User] = None) -> Dict:
    """Get user preferences with fallbacks"""
    try:
        if not user:
            user = get_current_user()
        
        if user:
            return {
                'language': user.preferred_language or 'hindi',
                'location': user.location or '',
                'age_group': user.age_group or 'adult',
                'user_id': user.id
            }
        else:
            # Default preferences for anonymous users
            return {
                'language': session.get('language', 'hindi'),
                'location': '',
                'age_group': 'adult',
                'user_id': None
            }
            
    except Exception as e:
        logger.error(f"Error getting user preferences: {e}")
        return {
            'language': 'hindi',
            'location': '',
            'age_group': 'adult',
            'user_id': None
        }

def validate_mood_input(mood_text: str) -> Dict:
    """Validate and clean mood input"""
    try:
        if not mood_text or not mood_text.strip():
            return {
                'valid': False,
                'error': 'Mood input cannot be empty',
                'cleaned_text': ''
            }
        
        # Clean the text
        cleaned_text = mood_text.strip()
        
        # Remove excessive whitespace
        cleaned_text = re.sub(r'\s+', ' ', cleaned_text)
        
        # Check length constraints
        if len(cleaned_text) > 500:
            return {
                'valid': False,
                'error': 'Mood input too long (max 500 characters)',
                'cleaned_text': cleaned_text[:500]
            }
        
        if len(cleaned_text) < 2:
            return {
                'valid': False,
                'error': 'Mood input too short (min 2 characters)',
                'cleaned_text': cleaned_text
            }
        
        return {
            'valid': True,
            'error': None,
            'cleaned_text': cleaned_text
        }
        
    except Exception as e:
        logger.error(f"Error validating mood input: {e}")
        return {
            'valid': False,
            'error': 'Invalid mood input',
            'cleaned_text': mood_text if mood_text else ''
        }

def detect_platform_preferences(user: Optional[User] = None) -> List[str]:
    """Detect user's platform preferences based on history or defaults"""
    try:
        # Default platforms for Indian users
        default_platforms = ['youtube', 'spotify', 'jiohotstar']
        
        if not user:
            return default_platforms
        
        # Could analyze user's past selections or preferences
        # For now, return defaults
        return default_platforms
        
    except Exception as e:
        logger.error(f"Error detecting platform preferences: {e}")
        return ['youtube', 'spotify']

def format_duration(seconds: int) -> str:
    """Format duration in seconds to human readable format"""
    try:
        if seconds < 60:
            return f"{seconds}s"
        elif seconds < 3600:
            minutes = seconds // 60
            remaining_seconds = seconds % 60
            return f"{minutes}m {remaining_seconds}s" if remaining_seconds else f"{minutes}m"
        else:
            hours = seconds // 3600
            remaining_minutes = (seconds % 3600) // 60
            return f"{hours}h {remaining_minutes}m" if remaining_minutes else f"{hours}h"
            
    except Exception:
        return "Unknown"

def get_time_based_greeting(language: str = 'hindi') -> str:
    """Get time-based greeting in specified language"""
    try:
        current_hour = datetime.now().hour
        
        greetings = {
            'hindi': {
                'morning': 'सुप्रभात',      # 5 AM - 12 PM
                'afternoon': 'नमस्कार',     # 12 PM - 5 PM
                'evening': 'शुभ संध्या',    # 5 PM - 8 PM
                'night': 'शुभ रात्रि'       # 8 PM - 5 AM
            },
            'tamil': {
                'morning': 'வணக்கம்',
                'afternoon': 'வணக்கம்',
                'evening': 'வணக்கம்',
                'night': 'இனிய இரவு'
            },
            'telugu': {
                'morning': 'సుప్రభాతం',
                'afternoon': 'నమస్కారం',
                'evening': 'శుభ సాయంత్రం',
                'night': 'శుభ రాత్రి'
            },
            'english': {
                'morning': 'Good Morning',
                'afternoon': 'Good Afternoon',
                'evening': 'Good Evening',
                'night': 'Good Night'
            }
        }
        
        # Determine time of day
        if 5 <= current_hour < 12:
            time_period = 'morning'
        elif 12 <= current_hour < 17:
            time_period = 'afternoon'
        elif 17 <= current_hour < 20:
            time_period = 'evening'
        else:
            time_period = 'night'
        
        lang_greetings = greetings.get(language, greetings['english'])
        return lang_greetings.get(time_period, lang_greetings['morning'])
        
    except Exception as e:
        logger.error(f"Error getting greeting: {e}")
        return "Hello"

def generate_content_hash(content: Dict) -> str:
    """Generate a hash for content deduplication"""
    try:
        # Create a string representation of key content fields
        content_string = f"{content.get('title', '')}{content.get('platform', '')}{content.get('type', '')}"
        return hashlib.md5(content_string.encode()).hexdigest()
        
    except Exception as e:
        logger.error(f"Error generating content hash: {e}")
        return ""

def deduplicate_content(content_list: List[Dict]) -> List[Dict]:
    """Remove duplicate content from list"""
    try:
        seen_hashes = set()
        unique_content = []
        
        for content in content_list:
            content_hash = generate_content_hash(content)
            if content_hash and content_hash not in seen_hashes:
                seen_hashes.add(content_hash)
                unique_content.append(content)
        
        return unique_content
        
    except Exception as e:
        logger.error(f"Error deduplicating content: {e}")
        return content_list

def get_platform_display_name(platform: str) -> str:
    """Get display name for platform"""
    platform_names = {
        'youtube': 'YouTube',
        'spotify': 'Spotify',
        'jiohotstar': 'JioHotstar',
        'zee5': 'ZEE5',
        'sonyliv': 'SonyLIV',
        'jiosaavn': 'JioSaavn',
        'gaana': 'Gaana'
    }
    return platform_names.get(platform, platform.title())

def is_festival_season() -> bool:
    """Check if current time is festival season in India"""
    try:
        current_month = datetime.now().month
        
        # Major festival months in India
        festival_months = [9, 10, 11, 12, 1, 3, 4]  # Sep-Jan (Dussehra to Makar Sankranti), Mar-Apr (Holi to Ram Navami)
        
        return current_month in festival_months
        
    except Exception:
        return False

def get_mood_emoji(mood: str) -> str:
    """Get emoji representation for mood"""
    mood_emojis = {
        'happy': '😊',
        'excited': '🤩',
        'calm': '😌',
        'stressed': '😰',
        'sad': '😢',
        'angry': '😠',
        'loving': '🥰',
        'fearful': '😨',
        'neutral': '😐',
        'energetic': '⚡',
        'peaceful': '🕊️',
        'joyful': '😄'
    }
    return mood_emojis.get(mood.lower(), '😐')

def log_user_interaction(action: str, details: Dict, user: Optional[User] = None):
    """Log user interactions for analytics"""
    try:
        if not user:
            user = get_current_user()
        
        log_data = {
            'timestamp': datetime.utcnow().isoformat(),
            'action': action,
            'user_id': user.id if user else None,
            'details': details,
            'ip_address': request.remote_addr if request else None,
            'user_agent': request.user_agent.string if request else None
        }
        
        # In a production system, this would go to a proper analytics service
        logger.info(f"User interaction: {log_data}")
        
    except Exception as e:
        logger.error(f"Error logging user interaction: {e}")

def get_content_age_rating(content: Dict) -> str:
    """Get age rating for content"""
    try:
        # Simple age rating based on content type and platform
        if content.get('platform') in ['youtube']:
            return 'General'
        elif 'devotional' in content.get('genres', []):
            return 'All Ages'
        elif 'comedy' in content.get('genres', []):
            return 'Teen+'
        else:
            return 'General'
            
    except Exception:
        return 'General'

def sanitize_search_query(query: str) -> str:
    """Sanitize search query to prevent injection attacks"""
    try:
        if not query:
            return ""
        
        # Remove potentially harmful characters
        sanitized = re.sub(r'[<>"\';\\]', '', query)
        
        # Limit length
        sanitized = sanitized[:200]
        
        # Remove excessive whitespace
        sanitized = re.sub(r'\s+', ' ', sanitized).strip()
        
        return sanitized
        
    except Exception as e:
        logger.error(f"Error sanitizing search query: {e}")
        return ""

def get_regional_language_name(lang_code: str, display_language: str = 'english') -> str:
    """Get regional language name in specified display language"""
    language_names = {
        'english': {
            'hindi': 'Hindi',
            'tamil': 'Tamil', 
            'telugu': 'Telugu',
            'gujarati': 'Gujarati',
            'marathi': 'Marathi',
            'bengali': 'Bengali',
            'kannada': 'Kannada',
            'malayalam': 'Malayalam',
            'punjabi': 'Punjabi',
            'odia': 'Odia'
        },
        'hindi': {
            'hindi': 'हिंदी',
            'tamil': 'तमिल',
            'telugu': 'तेलुगु',
            'gujarati': 'गुजराती',
            'marathi': 'मराठी',
            'bengali': 'बंगाली',
            'kannada': 'कन्नड़',
            'malayalam': 'मलयालम',
            'punjabi': 'पंजाबी',
            'odia': 'ओड़िया'
        }
    }
    
    display_names = language_names.get(display_language, language_names['english'])
    return display_names.get(lang_code, lang_code.title())
