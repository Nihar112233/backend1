from flask import render_template, request, redirect, url_for, flash, session
from app import app, db
from models import User, MoodHistory, Content, Recommendation
from services.sentiment_analyzer import SentimentAnalyzer
from services.content_recommender import ContentRecommender
from services.cultural_context import CulturalContext
from utils.helpers import get_current_user, create_user_session
import logging

logger = logging.getLogger(__name__)

# Initialize services
sentiment_analyzer = SentimentAnalyzer()
content_recommender = ContentRecommender()
cultural_context = CulturalContext()

@app.route('/')
def index():
    """Homepage with mood selection interface"""
    try:
        user = get_current_user()
        cultural_events = cultural_context.get_current_events()
        
        # Get mood categories with cultural context
        mood_categories = {
            'positive': {
                'utsah': 'उत्साह (Excitement/Energy)',
                'khushi': 'खुशी (Happiness)',
                'santosham': 'సంతోషం (Joy in Telugu)',
                'ananda': 'आनंद (Bliss)',
                'prasannata': 'प्रसन्नता (Cheerfulness)'
            },
            'calm': {
                'shanti': 'शांति (Peace)',
                'sukoon': 'सुकून (Tranquility)',
                'vishranti': 'विश्रांति (Rest)',
                'sama': 'సమ (Calmness in Telugu)',
                'amaidhi': 'அமைதி (Peace in Tamil)'
            },
            'reflective': {
                'vichar': 'विचार (Contemplation)',
                'manana': 'मनन (Reflection)',
                'chintan': 'चिंतन (Meditation)',
                'introspection': 'आत्मनिरीक्षण (Self-reflection)',
                'gyan': 'ज्ञान (Knowledge-seeking)'
            },
            'stressed': {
                'tension': 'तनाव (Stress)',
                'chinta': 'चिंता (Worry)',
                'pareshani': 'परेशानी (Trouble)',
                'pressure': 'दबाव (Pressure)',
                'mansik_dabav': 'मानसिक दबाव (Mental stress)'
            }
        }
        
        return render_template('index.html', 
                             mood_categories=mood_categories,
                             cultural_events=cultural_events,
                             user=user)
    except Exception as e:
        logger.error(f"Error in index route: {e}")
        flash("An error occurred while loading the page", "error")
        return render_template('index.html', mood_categories={}, cultural_events=[])

@app.route('/analyze_mood', methods=['POST'])
def analyze_mood():
    """Analyze user's mood input and redirect to recommendations"""
    try:
        mood_input = request.form.get('mood_input', '').strip()
        selected_mood = request.form.get('selected_mood', '').strip()
        language = request.form.get('language', 'hindi')
        platforms = request.form.getlist('platforms')
        
        if not mood_input and not selected_mood:
            flash("कृपया अपनी मन:स्थिति बताएं (Please share your mood)", "error")
            return redirect(url_for('index'))
        
        # Use text input for analysis if provided, otherwise use selected mood
        mood_text = mood_input if mood_input else selected_mood
        
        # Analyze sentiment
        mood_analysis = sentiment_analyzer.analyze_mood(mood_text, language)
        
        # Store mood history
        user = get_current_user()
        if user:
            mood_history = MoodHistory()
            mood_history.user_id = user.id
            mood_history.mood = mood_analysis['primary_mood']
            mood_history.context = {
                'input_text': mood_text,
                'language': language,
                'platforms': platforms,
                'sentiment_scores': mood_analysis['sentiment_scores']
            }
            db.session.add(mood_history)
            db.session.commit()
        
        # Store in session for recommendations
        session['current_mood'] = mood_analysis
        session['preferred_platforms'] = platforms
        session['language'] = language
        
        return redirect(url_for('recommendations'))
        
    except Exception as e:
        logger.error(f"Error in analyze_mood: {e}")
        flash("मूड विश्लेषण में त्रुटि (Error in mood analysis)", "error")
        return redirect(url_for('index'))

@app.route('/recommendations')
def recommendations():
    """Display personalized content recommendations based on mood"""
    try:
        # Get mood analysis from session
        mood_analysis = session.get('current_mood')
        platforms = session.get('preferred_platforms', [])
        language = session.get('language', 'hindi')
        
        if not mood_analysis:
            flash("कृपया पहले अपना मूड चुनें (Please select your mood first)", "error")
            return redirect(url_for('index'))
        
        user = get_current_user()
        
        # Get recommendations from content recommender
        recommendations_data = content_recommender.get_recommendations(
            mood=mood_analysis['primary_mood'],
            language=language,
            platforms=platforms,
            user=user,
            mood_analysis=mood_analysis
        )
        
        # Get cultural context for better recommendations
        cultural_boosts = cultural_context.get_cultural_boosts(language)
        
        return render_template('recommendations.html',
                             recommendations=recommendations_data,
                             mood_analysis=mood_analysis,
                             cultural_boosts=cultural_boosts,
                             language=language,
                             platforms=platforms)
        
    except Exception as e:
        logger.error(f"Error in recommendations: {e}")
        flash("सिफारिशें लोड करने में त्रुटि (Error loading recommendations)", "error")
        return redirect(url_for('index'))

@app.route('/profile')
def profile():
    """User profile and preferences"""
    try:
        user = get_current_user()
        if not user:
            return redirect(url_for('create_profile'))
        
        # Get user's mood history
        recent_moods = MoodHistory.query.filter_by(user_id=user.id)\
                                       .order_by(MoodHistory.timestamp.desc())\
                                       .limit(10).all()
        
        return render_template('profile.html', user=user, recent_moods=recent_moods)
        
    except Exception as e:
        logger.error(f"Error in profile route: {e}")
        flash("प्रोफाइल लोड करने में त्रुटि (Error loading profile)", "error")
        return redirect(url_for('index'))

@app.route('/create_profile', methods=['GET', 'POST'])
def create_profile():
    """Create user profile"""
    try:
        if request.method == 'POST':
            username = request.form.get('username', '').strip()
            language = request.form.get('language', 'hindi')
            location = request.form.get('location', '').strip()
            age_group = request.form.get('age_group', '')
            
            if not username:
                flash("कृपया उपयोगकर्ता नाम दर्ज करें (Please enter username)", "error")
                return render_template('profile.html')
            
            # Check if username exists
            existing_user = User.query.filter_by(username=username).first()
            if existing_user:
                flash("यह उपयोगकर्ता नाम पहले से मौजूद है (Username already exists)", "error")
                return render_template('profile.html')
            
            # Create new user
            user = User()
            user.username = username
            user.preferred_language = language
            user.location = location
            user.age_group = age_group
            db.session.add(user)
            db.session.commit()
            
            # Create session
            create_user_session(user)
            
            flash("प्रोफाइल सफलतापूर्वक बनाई गई (Profile created successfully)", "success")
            return redirect(url_for('index'))
        
        return render_template('profile.html')
        
    except Exception as e:
        logger.error(f"Error in create_profile: {e}")
        flash("प्रोफाइल बनाने में त्रुटि (Error creating profile)", "error")
        return render_template('profile.html')

@app.errorhandler(404)
def not_found(error):
    return render_template('index.html'), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {error}")
    db.session.rollback()
    flash("सर्वर त्रुटि (Server error)", "error")
    return render_template('index.html'), 500
