from app import db
from datetime import datetime
from sqlalchemy import JSON

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    preferred_language = db.Column(db.String(10), default='hindi')
    location = db.Column(db.String(100))
    age_group = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    mood_histories = db.relationship('MoodHistory', backref='user', lazy=True)
    preferences = db.relationship('UserPreference', backref='user', lazy=True)

class MoodHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    mood = db.Column(db.String(50), nullable=False)
    context = db.Column(JSON)  # Store additional context like time, weather, etc.
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class UserPreference(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    platform = db.Column(db.String(50), nullable=False)
    content_type = db.Column(db.String(50), nullable=False)  # video, music, podcast, book
    genre_preferences = db.Column(JSON)
    language_preferences = db.Column(JSON)

class Content(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    platform = db.Column(db.String(50), nullable=False)
    content_type = db.Column(db.String(50), nullable=False)
    genre = db.Column(db.String(100))
    language = db.Column(db.String(20))
    mood_tags = db.Column(JSON)  # List of mood tags this content is suitable for
    cultural_tags = db.Column(JSON)  # Cultural context tags
    content_metadata = db.Column(JSON)  # Platform-specific metadata
    external_id = db.Column(db.String(100))  # ID from external platform
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Recommendation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    content_id = db.Column(db.Integer, db.ForeignKey('content.id'), nullable=False)
    mood = db.Column(db.String(50), nullable=False)
    confidence_score = db.Column(db.Float)
    recommendation_reason = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    content = db.relationship('Content', backref='recommendations')

class CulturalEvent(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    date = db.Column(db.Date, nullable=False)
    region = db.Column(db.String(50))
    mood_influence = db.Column(JSON)  # How this event influences mood
    content_boost = db.Column(JSON)  # What type of content to boost during this event
