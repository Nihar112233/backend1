/**
 * MoodConnect - Main JavaScript File
 * Handles all client-side interactions for the mood-based content recommender
 */

// Global application state
const MoodConnect = {
    currentLanguage: 'hindi',
    selectedMood: null,
    selectedPlatforms: [],
    isAnalyzing: false,
    cache: new Map(),
    
    // Configuration
    config: {
        maxMoodInputLength: 500,
        minMoodInputLength: 2,
        cacheTimeout: 300000, // 5 minutes
        debounceDelay: 300,
        animationDuration: 300
    }
};

// Utility Functions
const Utils = {
    /**
     * Debounce function to limit rapid function calls
     */
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    },

    /**
     * Sanitize user input to prevent XSS
     */
    sanitizeInput(input) {
        const div = document.createElement('div');
        div.textContent = input;
        return div.innerHTML;
    },

    /**
     * Format time in user-friendly format
     */
    formatTime(date) {
        return new Intl.DateTimeFormat('en-IN', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
        }).format(date);
    },

    /**
     * Get appropriate greeting based on time and language
     */
    getTimeBasedGreeting(language = 'hindi') {
        const hour = new Date().getHours();
        
        const greetings = {
            hindi: {
                morning: 'सुप्रभात! आज आपका मूड कैसा है?',
                afternoon: 'नमस्कार! आज आपका मूड कैसा है?',
                evening: 'शुभ संध्या! आज आपका मूड कैसा है?',
                night: 'शुभ रात्रि! आपका मूड कैसा है?'
            },
            tamil: {
                morning: 'வணக்கம்! இன்று உங்கள் மனநிலை எப்படி?',
                afternoon: 'வணக்கம்! உங்கள் மனநிலை எப்படி?',
                evening: 'வணக்கம்! உங்கள் மனநிலை எப்படி?',
                night: 'இனிய இரவு! உங்கள் மனநிலை எப்படி?'
            },
            telugu: {
                morning: 'సుప్రభాతం! ఈరోజు మీ మూడ్ ఎలా ఉంది?',
                afternoon: 'నమస్కారం! మీ మూడ్ ఎలా ఉంది?',
                evening: 'శుభ సాయంత్రం! మీ మూడ్ ఎలా ఉంది?',
                night: 'శుభ రాత్రి! మీ మూడ్ ఎలా ఉంది?'
            },
            english: {
                morning: 'Good morning! How are you feeling today?',
                afternoon: 'Good afternoon! How are you feeling?',
                evening: 'Good evening! How are you feeling?',
                night: 'Good night! How are you feeling?'
            }
        };

        let timeOfDay;
        if (hour >= 5 && hour < 12) timeOfDay = 'morning';
        else if (hour >= 12 && hour < 17) timeOfDay = 'afternoon';
        else if (hour >= 17 && hour < 20) timeOfDay = 'evening';
        else timeOfDay = 'night';

        return greetings[language]?.[timeOfDay] || greetings.english[timeOfDay];
    },

    /**
     * Show toast notification
     */
    showToast(message, type = 'info', duration = 3000) {
        // Create toast element
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type} border-0`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">${message}</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;

        // Add to toast container or create one
        let toastContainer = document.querySelector('.toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }

        toastContainer.appendChild(toast);

        // Initialize and show toast
        const bsToast = new bootstrap.Toast(toast, { delay: duration });
        bsToast.show();

        // Remove from DOM after hiding
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    },

    /**
     * Smooth scroll to element
     */
    scrollTo(element, offset = 0) {
        const targetPosition = element.offsetTop - offset;
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
};

// Language Management
const LanguageManager = {
    /**
     * Initialize language-specific functionality
     */
    init() {
        this.detectBrowserLanguage();
        this.setupLanguageToggle();
        this.updatePlaceholders();
    },

    /**
     * Detect browser language and set default
     */
    detectBrowserLanguage() {
        const browserLang = navigator.language.toLowerCase();
        
        if (browserLang.includes('hi')) {
            MoodConnect.currentLanguage = 'hindi';
        } else if (browserLang.includes('ta')) {
            MoodConnect.currentLanguage = 'tamil';
        } else if (browserLang.includes('te')) {
            MoodConnect.currentLanguage = 'telugu';
        } else {
            MoodConnect.currentLanguage = 'english';
        }

        // Set radio button if exists
        const langRadio = document.getElementById(`lang-${MoodConnect.currentLanguage}`);
        if (langRadio) {
            langRadio.checked = true;
        }
    },

    /**
     * Setup language toggle functionality
     */
    setupLanguageToggle() {
        const languageRadios = document.querySelectorAll('input[name="language"]');
        
        languageRadios.forEach(radio => {
            radio.addEventListener('change', (e) => {
                if (e.target.checked) {
                    this.changeLanguage(e.target.value);
                }
            });
        });
    },

    /**
     * Change application language
     */
    changeLanguage(newLanguage) {
        MoodConnect.currentLanguage = newLanguage;
        this.updatePlaceholders();
        this.updateUILanguage();
        
        // Store language preference
        localStorage.setItem('moodconnect_language', newLanguage);
        
        Utils.showToast(
            `Language changed to ${newLanguage.charAt(0).toUpperCase() + newLanguage.slice(1)}`,
            'success'
        );
    },

    /**
     * Update input placeholders based on language
     */
    updatePlaceholders() {
        const moodInput = document.getElementById('moodInput');
        if (moodInput) {
            const greeting = Utils.getTimeBasedGreeting(MoodConnect.currentLanguage);
            moodInput.placeholder = greeting;
        }
    },

    /**
     * Update UI text based on selected language
     */
    updateUILanguage() {
        // Update dynamic content based on language
        const languageContent = {
            hindi: {
                analyzing: 'विश्लेषण हो रहा है...',
                getRecommendations: 'सिफारिशें पाएं',
                error: 'त्रुटि',
                success: 'सफलता'
            },
            tamil: {
                analyzing: 'ஆய்வு செய்யப்படுகிறது...',
                getRecommendations: 'பரிந்துரைகளைப் பெறுங்கள்',
                error: 'பிழை',
                success: 'வெற்றி'
            },
            telugu: {
                analyzing: 'విశ్లేషణ జరుగుతోంది...',
                getRecommendations: 'సిఫార్సులను పొందండి',
                error: 'లోపం',
                success: 'విజయం'
            },
            english: {
                analyzing: 'Analyzing...',
                getRecommendations: 'Get Recommendations',
                error: 'Error',
                success: 'Success'
            }
        };

        const content = languageContent[MoodConnect.currentLanguage] || languageContent.english;
        
        // Update button text
        const analyzeBtn = document.getElementById('analyzeBtn');
        if (analyzeBtn && !MoodConnect.isAnalyzing) {
            analyzeBtn.innerHTML = `
                <i data-feather="search" class="me-2"></i>
                ${content.getRecommendations}
            `;
            feather.replace();
        }
    }
};

// Mood Input Management
const MoodInputManager = {
    /**
     * Initialize mood input functionality
     */
    init() {
        this.setupMoodInput();
        this.setupMoodButtons();
        this.setupFormValidation();
    },

    /**
     * Setup custom mood input textarea
     */
    setupMoodInput() {
        const moodInput = document.getElementById('moodInput');
        if (!moodInput) return;

        // Character counter
        this.addCharacterCounter(moodInput);

        // Auto-resize textarea
        this.setupAutoResize(moodInput);

        // Input validation
        moodInput.addEventListener('input', Utils.debounce((e) => {
            this.validateMoodInput(e.target);
            this.clearSelectedMoodButtons();
        }, MoodConnect.config.debounceDelay));

        // Language detection
        moodInput.addEventListener('input', Utils.debounce((e) => {
            this.detectInputLanguage(e.target.value);
        }, 500));
    },

    /**
     * Add character counter to mood input
     */
    addCharacterCounter(input) {
        const counter = document.createElement('div');
        counter.className = 'char-counter text-muted small mt-1';
        counter.textContent = `0/${MoodConnect.config.maxMoodInputLength}`;
        
        input.parentNode.appendChild(counter);

        input.addEventListener('input', (e) => {
            const length = e.target.value.length;
            counter.textContent = `${length}/${MoodConnect.config.maxMoodInputLength}`;
            
            if (length > MoodConnect.config.maxMoodInputLength * 0.9) {
                counter.className = 'char-counter text-warning small mt-1';
            } else if (length >= MoodConnect.config.maxMoodInputLength) {
                counter.className = 'char-counter text-danger small mt-1';
            } else {
                counter.className = 'char-counter text-muted small mt-1';
            }
        });
    },

    /**
     * Setup auto-resize for textarea
     */
    setupAutoResize(textarea) {
        textarea.addEventListener('input', () => {
            textarea.style.height = 'auto';
            textarea.style.height = Math.min(textarea.scrollHeight, 150) + 'px';
        });
    },

    /**
     * Setup mood selection buttons
     */
    setupMoodButtons() {
        const moodButtons = document.querySelectorAll('input[name="selected_mood"]');
        
        moodButtons.forEach(button => {
            button.addEventListener('change', (e) => {
                if (e.target.checked) {
                    MoodConnect.selectedMood = e.target.value;
                    this.clearMoodInput();
                    this.addMoodButtonAnimation(e.target);
                }
            });
        });
    },

    /**
     * Clear mood input when button is selected
     */
    clearMoodInput() {
        const moodInput = document.getElementById('moodInput');
        if (moodInput) {
            moodInput.value = '';
            moodInput.style.height = 'auto';
        }
    },

    /**
     * Clear selected mood buttons when typing
     */
    clearSelectedMoodButtons() {
        const moodButtons = document.querySelectorAll('input[name="selected_mood"]');
        moodButtons.forEach(button => {
            button.checked = false;
        });
        MoodConnect.selectedMood = null;
    },

    /**
     * Add animation to selected mood button
     */
    addMoodButtonAnimation(button) {
        const label = button.nextElementSibling;
        if (label) {
            label.style.transform = 'scale(1.05)';
            setTimeout(() => {
                label.style.transform = '';
            }, 200);
        }
    },

    /**
     * Validate mood input
     */
    validateMoodInput(input) {
        const value = input.value.trim();
        const isValid = value.length >= MoodConnect.config.minMoodInputLength && 
                       value.length <= MoodConnect.config.maxMoodInputLength;

        if (value && !isValid) {
            input.classList.add('is-invalid');
            this.showInputError(input, 'Mood input must be between 2-500 characters');
        } else {
            input.classList.remove('is-invalid');
            this.hideInputError(input);
        }

        return isValid;
    },

    /**
     * Show input validation error
     */
    showInputError(input, message) {
        let errorDiv = input.parentNode.querySelector('.invalid-feedback');
        if (!errorDiv) {
            errorDiv = document.createElement('div');
            errorDiv.className = 'invalid-feedback';
            input.parentNode.appendChild(errorDiv);
        }
        errorDiv.textContent = message;
    },

    /**
     * Hide input validation error
     */
    hideInputError(input) {
        const errorDiv = input.parentNode.querySelector('.invalid-feedback');
        if (errorDiv) {
            errorDiv.remove();
        }
    },

    /**
     * Detect input language and suggest language change
     */
    detectInputLanguage(text) {
        if (!text || text.length < 10) return;

        // Simple script detection
        let detectedLang = 'english';
        
        if (/[\u0900-\u097F]/.test(text)) {
            detectedLang = 'hindi';
        } else if (/[\u0B80-\u0BFF]/.test(text)) {
            detectedLang = 'tamil';
        } else if (/[\u0C00-\u0C7F]/.test(text)) {
            detectedLang = 'telugu';
        }

        // Suggest language change if different from current
        if (detectedLang !== MoodConnect.currentLanguage) {
            this.suggestLanguageChange(detectedLang);
        }
    },

    /**
     * Suggest language change based on input
     */
    suggestLanguageChange(detectedLang) {
        const suggestions = {
            hindi: 'हिंदी',
            tamil: 'தமிழ்',
            telugu: 'తెలుగు',
            english: 'English'
        };

        const shouldSuggest = !sessionStorage.getItem(`suggested_${detectedLang}`);
        
        if (shouldSuggest) {
            Utils.showToast(
                `Detected ${suggestions[detectedLang]} text. Switch language for better analysis?`,
                'info',
                5000
            );
            sessionStorage.setItem(`suggested_${detectedLang}`, 'true');
        }
    },

    /**
     * Setup form validation
     */
    setupFormValidation() {
        const form = document.getElementById('moodForm');
        if (!form) return;

        form.addEventListener('submit', (e) => {
            if (!this.validateForm(form)) {
                e.preventDefault();
                return false;
            }
            
            this.handleFormSubmission();
        });
    },

    /**
     * Validate entire form
     */
    validateForm(form) {
        const moodInput = form.querySelector('#moodInput');
        const selectedMood = form.querySelector('input[name="selected_mood"]:checked');
        const selectedPlatforms = form.querySelectorAll('input[name="platforms"]:checked');

        // Check if mood is provided
        const hasMoodInput = moodInput && moodInput.value.trim();
        const hasSelectedMood = selectedMood;

        if (!hasMoodInput && !hasSelectedMood) {
            Utils.showToast(
                'कृपया अपना मूड बताएं या चुनें / Please share or select your mood',
                'danger'
            );
            return false;
        }

        // Validate mood input if provided
        if (hasMoodInput && !this.validateMoodInput(moodInput)) {
            return false;
        }

        // Check platform selection
        if (selectedPlatforms.length === 0) {
            Utils.showToast(
                'कृपया कम से कम एक प्लेटफॉर्म चुनें / Please select at least one platform',
                'danger'
            );
            return false;
        }

        return true;
    },

    /**
     * Handle form submission
     */
    handleFormSubmission() {
        const analyzeBtn = document.getElementById('analyzeBtn');
        if (analyzeBtn) {
            MoodConnect.isAnalyzing = true;
            
            const originalHTML = analyzeBtn.innerHTML;
            analyzeBtn.innerHTML = `
                <span class="spinner-border spinner-border-sm me-2" role="status"></span>
                विश्लेषण हो रहा है... / Analyzing...
            `;
            analyzeBtn.disabled = true;

            // Add loading class to form
            const form = document.getElementById('moodForm');
            if (form) {
                form.classList.add('analyzing');
            }
        }
    }
};

// Platform Selection Management
const PlatformManager = {
    /**
     * Initialize platform selection functionality
     */
    init() {
        this.setupPlatformSelection();
        this.loadSavedPreferences();
    },

    /**
     * Setup platform selection checkboxes
     */
    setupPlatformSelection() {
        const platformCheckboxes = document.querySelectorAll('input[name="platforms"]');
        
        platformCheckboxes.forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                this.handlePlatformChange(e.target);
                this.savePlatformPreferences();
            });
        });
    },

    /**
     * Handle platform selection change
     */
    handlePlatformChange(checkbox) {
        const checkedPlatforms = document.querySelectorAll('input[name="platforms"]:checked');
        
        // Ensure at least one platform is selected
        if (checkedPlatforms.length === 0) {
            checkbox.checked = true;
            Utils.showToast(
                'कम से कम एक प्लेटफॉर्म चुनें / Please select at least one platform',
                'warning'
            );
            return;
        }

        // Update global state
        MoodConnect.selectedPlatforms = Array.from(checkedPlatforms).map(cb => cb.value);

        // Add visual feedback
        this.addPlatformSelectionAnimation(checkbox);
    },

    /**
     * Add animation to platform selection
     */
    addPlatformSelectionAnimation(checkbox) {
        const label = checkbox.nextElementSibling;
        if (label) {
            label.style.transform = checkbox.checked ? 'scale(1.02)' : 'scale(0.98)';
            setTimeout(() => {
                label.style.transform = '';
            }, 150);
        }
    },

    /**
     * Save platform preferences to localStorage
     */
    savePlatformPreferences() {
        localStorage.setItem('moodconnect_platforms', JSON.stringify(MoodConnect.selectedPlatforms));
    },

    /**
     * Load saved platform preferences
     */
    loadSavedPreferences() {
        const savedPlatforms = localStorage.getItem('moodconnect_platforms');
        if (savedPlatforms) {
            try {
                const platforms = JSON.parse(savedPlatforms);
                platforms.forEach(platform => {
                    const checkbox = document.getElementById(`platform-${platform}`);
                    if (checkbox) {
                        checkbox.checked = true;
                    }
                });
                MoodConnect.selectedPlatforms = platforms;
            } catch (e) {
                console.warn('Failed to load saved platform preferences:', e);
            }
        }
    }
};

// Content Interaction Management
const ContentManager = {
    /**
     * Initialize content interaction functionality
     */
    init() {
        this.setupContentCards();
        this.setupContentFilters();
        this.setupContentSharing();
    },

    /**
     * Setup content card interactions
     */
    setupContentCards() {
        // Add hover effects and click tracking
        document.addEventListener('click', (e) => {
            // Handle content card clicks
            if (e.target.closest('.content-card a, .music-card a, .podcast-card a')) {
                this.trackContentInteraction(e.target.closest('a'));
            }

            // Handle platform badge clicks
            if (e.target.closest('.badge')) {
                this.handlePlatformBadgeClick(e.target.closest('.badge'));
            }
        });

        // Setup lazy loading for images
        this.setupLazyLoading();
    },

    /**
     * Setup lazy loading for content images
     */
    setupLazyLoading() {
        const images = document.querySelectorAll('img[data-src]');
        
        if ('IntersectionObserver' in window) {
            const imageObserver = new IntersectionObserver((entries, observer) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        const img = entry.target;
                        img.src = img.dataset.src;
                        img.classList.remove('lazy');
                        imageObserver.unobserve(img);
                    }
                });
            });

            images.forEach(img => imageObserver.observe(img));
        } else {
            // Fallback for browsers without IntersectionObserver
            images.forEach(img => {
                img.src = img.dataset.src;
            });
        }
    },

    /**
     * Track content interaction for analytics
     */
    trackContentInteraction(link) {
        const card = link.closest('.card');
        if (!card) return;

        const data = {
            title: card.querySelector('.card-title')?.textContent?.trim() || 'Unknown',
            platform: card.querySelector('.badge')?.textContent?.trim() || 'Unknown',
            type: card.classList.contains('music-card') ? 'music' : 
                  card.classList.contains('podcast-card') ? 'podcast' : 'video',
            url: link.href,
            timestamp: new Date().toISOString(),
            mood: MoodConnect.selectedMood || 'unknown',
            language: MoodConnect.currentLanguage
        };

        // Store interaction locally
        this.storeInteraction(data);

        // Show feedback
        Utils.showToast('Opening content...', 'info', 1500);
    },

    /**
     * Store user interaction data
     */
    storeInteraction(data) {
        try {
            const interactions = JSON.parse(localStorage.getItem('moodconnect_interactions') || '[]');
            interactions.push(data);
            
            // Keep only last 100 interactions
            if (interactions.length > 100) {
                interactions.splice(0, interactions.length - 100);
            }
            
            localStorage.setItem('moodconnect_interactions', JSON.stringify(interactions));
        } catch (e) {
            console.warn('Failed to store interaction data:', e);
        }
    },

    /**
     * Handle platform badge clicks
     */
    handlePlatformBadgeClick(badge) {
        const platform = badge.textContent.toLowerCase().trim();
        Utils.showToast(`Filtering content for ${platform}`, 'info');
        
        // Could implement platform filtering here
        this.filterContentByPlatform(platform);
    },

    /**
     * Filter content by platform
     */
    filterContentByPlatform(platform) {
        const allCards = document.querySelectorAll('.content-card, .music-card, .podcast-card');
        
        allCards.forEach(card => {
            const cardPlatform = card.querySelector('.badge')?.textContent?.toLowerCase()?.trim();
            
            if (platform === 'all' || cardPlatform?.includes(platform)) {
                card.style.display = '';
                card.style.opacity = '1';
            } else {
                card.style.opacity = '0.3';
            }
        });
    },

    /**
     * Setup content filtering
     */
    setupContentFilters() {
        // Create filter buttons if they don't exist
        this.createFilterButtons();
    },

    /**
     * Create filter buttons for content
     */
    createFilterButtons() {
        const contentSections = document.querySelectorAll('.content-section');
        
        contentSections.forEach(section => {
            const title = section.querySelector('h3');
            if (!title) return;

            const filterContainer = document.createElement('div');
            filterContainer.className = 'content-filters mb-3';
            filterContainer.innerHTML = `
                <div class="btn-group btn-group-sm" role="group">
                    <button type="button" class="btn btn-outline-secondary active" data-filter="all">All</button>
                    <button type="button" class="btn btn-outline-secondary" data-filter="youtube">YouTube</button>
                    <button type="button" class="btn btn-outline-secondary" data-filter="spotify">Spotify</button>
                    <button type="button" class="btn btn-outline-secondary" data-filter="jio">Jio</button>
                </div>
            `;

            title.parentNode.insertBefore(filterContainer, title.nextSibling);

            // Add filter functionality
            filterContainer.addEventListener('click', (e) => {
                if (e.target.tagName === 'BUTTON') {
                    this.handleFilterClick(e.target, section);
                }
            });
        });
    },

    /**
     * Handle filter button click
     */
    handleFilterClick(button, section) {
        const filter = button.dataset.filter;
        
        // Update active button
        section.querySelectorAll('.content-filters button').forEach(btn => {
            btn.classList.remove('active');
        });
        button.classList.add('active');

        // Filter content
        this.filterSectionContent(section, filter);
    },

    /**
     * Filter content within a section
     */
    filterSectionContent(section, filter) {
        const cards = section.querySelectorAll('.content-card, .music-card, .podcast-card');
        
        cards.forEach(card => {
            const platform = card.querySelector('.badge')?.textContent?.toLowerCase() || '';
            const shouldShow = filter === 'all' || platform.includes(filter);
            
            if (shouldShow) {
                card.style.display = '';
                card.classList.add('fade-in');
            } else {
                card.style.display = 'none';
                card.classList.remove('fade-in');
            }
        });
    },

    /**
     * Setup content sharing functionality
     */
    setupContentSharing() {
        // Add share buttons to content cards
        document.addEventListener('click', (e) => {
            if (e.target.closest('.share-content')) {
                e.preventDefault();
                this.shareContent(e.target.closest('.card'));
            }
        });
    },

    /**
     * Share content using Web Share API or fallback
     */
    async shareContent(card) {
        const title = card.querySelector('.card-title')?.textContent || '';
        const description = card.querySelector('.card-text')?.textContent || '';
        const url = card.querySelector('a')?.href || window.location.href;

        const shareData = {
            title: `MoodConnect: ${title}`,
            text: description,
            url: url
        };

        try {
            if (navigator.share) {
                await navigator.share(shareData);
                Utils.showToast('Content shared successfully!', 'success');
            } else {
                // Fallback to clipboard
                await navigator.clipboard.writeText(`${title}\n${description}\n${url}`);
                Utils.showToast('Content details copied to clipboard!', 'success');
            }
        } catch (error) {
            console.warn('Sharing failed:', error);
            Utils.showToast('Unable to share content', 'warning');
        }
    }
};

// Performance and Accessibility
const AccessibilityManager = {
    /**
     * Initialize accessibility features
     */
    init() {
        this.setupKeyboardNavigation();
        this.setupAriaLabels();
        this.setupFocusManagement();
        this.setupReducedMotion();
    },

    /**
     * Setup keyboard navigation
     */
    setupKeyboardNavigation() {
        document.addEventListener('keydown', (e) => {
            // Handle Enter key on custom elements
            if (e.key === 'Enter' && e.target.closest('.mood-btn, .platform-btn')) {
                e.target.click();
            }

            // Handle Escape key
            if (e.key === 'Escape') {
                this.handleEscapeKey();
            }
        });
    },

    /**
     * Handle Escape key press
     */
    handleEscapeKey() {
        // Close any open modals or dropdowns
        const openDropdowns = document.querySelectorAll('.dropdown-menu.show');
        openDropdowns.forEach(dropdown => {
            bootstrap.Dropdown.getInstance(dropdown.previousElementSibling)?.hide();
        });
    },

    /**
     * Setup ARIA labels for better accessibility
     */
    setupAriaLabels() {
        // Add labels to interactive elements
        document.querySelectorAll('.mood-btn').forEach((btn, index) => {
            if (!btn.getAttribute('aria-label')) {
                const text = btn.textContent.trim();
                btn.setAttribute('aria-label', `Select mood: ${text}`);
            }
        });

        document.querySelectorAll('.platform-btn').forEach((btn, index) => {
            if (!btn.getAttribute('aria-label')) {
                const text = btn.textContent.trim();
                btn.setAttribute('aria-label', `Toggle platform: ${text}`);
            }
        });
    },

    /**
     * Setup focus management
     */
    setupFocusManagement() {
        // Improve focus visibility
        const style = document.createElement('style');
        style.textContent = `
            *:focus {
                outline: 2px solid var(--primary);
                outline-offset: 2px;
            }
            
            .btn:focus,
            .form-control:focus,
            .form-select:focus {
                box-shadow: 0 0 0 0.2rem rgba(0, 102, 204, 0.25);
            }
        `;
        document.head.appendChild(style);
    },

    /**
     * Setup reduced motion preferences
     */
    setupReducedMotion() {
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            // Disable animations
            const style = document.createElement('style');
            style.textContent = `
                *, *::before, *::after {
                    animation-duration: 0.01ms !important;
                    animation-iteration-count: 1 !important;
                    transition-duration: 0.01ms !important;
                }
            `;
            document.head.appendChild(style);
        }
    }
};

// Error Handling and Offline Support
const ErrorManager = {
    /**
     * Initialize error handling
     */
    init() {
        this.setupGlobalErrorHandling();
        this.setupOfflineSupport();
        this.setupNetworkStatusIndicator();
    },

    /**
     * Setup global error handling
     */
    setupGlobalErrorHandling() {
        window.addEventListener('error', (e) => {
            console.error('Global error:', e.error);
            this.handleError('An unexpected error occurred', e.error);
        });

        window.addEventListener('unhandledrejection', (e) => {
            console.error('Unhandled promise rejection:', e.reason);
            this.handleError('A network error occurred', e.reason);
        });
    },

    /**
     * Handle application errors
     */
    handleError(message, error) {
        Utils.showToast(message, 'danger', 5000);
        
        // Log error for debugging
        this.logError(error);
    },

    /**
     * Log error information
     */
    logError(error) {
        const errorInfo = {
            message: error?.message || 'Unknown error',
            stack: error?.stack || 'No stack trace',
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent,
            url: window.location.href,
            language: MoodConnect.currentLanguage
        };

        console.error('Error logged:', errorInfo);
        
        // In production, this would be sent to error tracking service
        localStorage.setItem('moodconnect_last_error', JSON.stringify(errorInfo));
    },

    /**
     * Setup offline support
     */
    setupOfflineSupport() {
        window.addEventListener('online', () => {
            Utils.showToast('Connection restored', 'success');
            this.syncOfflineData();
        });

        window.addEventListener('offline', () => {
            Utils.showToast('You are offline. Some features may be limited.', 'warning', 5000);
        });
    },

    /**
     * Sync offline data when connection is restored
     */
    syncOfflineData() {
        // Implement offline data synchronization if needed
        console.log('Syncing offline data...');
    },

    /**
     * Setup network status indicator
     */
    setupNetworkStatusIndicator() {
        if (!navigator.onLine) {
            const indicator = document.createElement('div');
            indicator.className = 'offline-indicator';
            indicator.innerHTML = `
                <div class="alert alert-warning mb-0 text-center">
                    <i data-feather="wifi-off" class="me-2"></i>
                    You are currently offline
                </div>
            `;
            document.body.insertBefore(indicator, document.body.firstChild);
        }
    }
};

// Main Application Initialization
const App = {
    /**
     * Initialize the application
     */
    init() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.startup());
        } else {
            this.startup();
        }
    },

    /**
     * Application startup
     */
    startup() {
        try {
            // Initialize all managers
            LanguageManager.init();
            MoodInputManager.init();
            PlatformManager.init();
            ContentManager.init();
            AccessibilityManager.init();
            ErrorManager.init();

            // Initialize Feather icons
            if (typeof feather !== 'undefined') {
                feather.replace();
            }

            // Setup page-specific functionality
            this.setupPageSpecificFeatures();

            // Setup analytics
            this.setupAnalytics();

            console.log('MoodConnect initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize MoodConnect:', error);
            ErrorManager.handleError('Failed to initialize application', error);
        }
    },

    /**
     * Setup page-specific features
     */
    setupPageSpecificFeatures() {
        const currentPage = this.getCurrentPage();
        
        switch (currentPage) {
            case 'home':
                this.setupHomePage();
                break;
            case 'recommendations':
                this.setupRecommendationsPage();
                break;
            case 'profile':
                this.setupProfilePage();
                break;
        }
    },

    /**
     * Get current page identifier
     */
    getCurrentPage() {
        const path = window.location.pathname;
        
        if (path === '/' || path.includes('index')) {
            return 'home';
        } else if (path.includes('recommendations')) {
            return 'recommendations';
        } else if (path.includes('profile')) {
            return 'profile';
        }
        
        return 'unknown';
    },

    /**
     * Setup home page specific features
     */
    setupHomePage() {
        // Auto-focus mood input after a delay
        setTimeout(() => {
            const moodInput = document.getElementById('moodInput');
            if (moodInput && !window.matchMedia('(max-width: 768px)').matches) {
                moodInput.focus();
            }
        }, 500);

        // Setup cultural events animation
        this.animateCulturalEvents();
    },

    /**
     * Setup recommendations page specific features
     */
    setupRecommendationsPage() {
        // Initialize charts if Chart.js is available
        if (typeof Chart !== 'undefined') {
            this.initializeCharts();
        }

        // Setup infinite scroll for content (if needed)
        this.setupInfiniteScroll();
    },

    /**
     * Setup profile page specific features
     */
    setupProfilePage() {
        // Initialize profile charts
        if (typeof Chart !== 'undefined') {
            this.initializeProfileCharts();
        }

        // Setup form validation
        this.setupProfileFormValidation();
    },

    /**
     * Animate cultural events
     */
    animateCulturalEvents() {
        const events = document.querySelectorAll('.event-card');
        events.forEach((event, index) => {
            setTimeout(() => {
                event.style.opacity = '0';
                event.style.transform = 'translateY(20px)';
                event.style.transition = 'all 0.5s ease';
                
                setTimeout(() => {
                    event.style.opacity = '1';
                    event.style.transform = 'translateY(0)';
                }, 100);
            }, index * 200);
        });
    },

    /**
     * Initialize charts
     */
    initializeCharts() {
        // This is handled by individual page scripts
        // but can be centralized here if needed
    },

    /**
     * Initialize profile charts
     */
    initializeProfileCharts() {
        // This is handled by profile page script
    },

    /**
     * Setup infinite scroll
     */
    setupInfiniteScroll() {
        // Implement if needed for loading more content
    },

    /**
     * Setup profile form validation
     */
    setupProfileFormValidation() {
        // Additional profile-specific validation
    },

    /**
     * Setup analytics
     */
    setupAnalytics() {
        // Track page views
        this.trackPageView();

        // Track user interactions
        this.trackUserInteractions();
    },

    /**
     * Track page view
     */
    trackPageView() {
        const pageData = {
            page: this.getCurrentPage(),
            timestamp: new Date().toISOString(),
            language: MoodConnect.currentLanguage,
            userAgent: navigator.userAgent
        };

        console.log('Page view:', pageData);
        // In production, send to analytics service
    },

    /**
     * Track user interactions
     */
    trackUserInteractions() {
        // Track button clicks, form submissions, etc.
        document.addEventListener('click', (e) => {
            if (e.target.closest('.btn, .nav-link, .card')) {
                const element = e.target.closest('.btn, .nav-link, .card');
                const interactionData = {
                    type: 'click',
                    element: element.tagName.toLowerCase(),
                    text: element.textContent?.trim()?.substring(0, 50) || '',
                    timestamp: new Date().toISOString()
                };
                
                console.log('User interaction:', interactionData);
                // In production, send to analytics service
            }
        });
    }
};

// Global helper functions for template access
window.MoodConnect = MoodConnect;
window.Utils = Utils;
window.setLanguage = (lang) => LanguageManager.changeLanguage(lang);
window.shareContent = (card) => ContentManager.shareContent(card);
window.exportMoodHistory = () => {
    // Function defined in profile template script
    console.log('Export mood history called');
};

// Initialize the application
App.init();
